'''
Created on Aug 22, 2012

@author: epstvxj
'''

from datagen.settings import datagen_logger
from datagen.shared import metrics, datagen_logging
from datagen.shared.constants import CAPTOOL_SUMMARY_FILENAME_SEARCH_STRING, \
    CAPTOOL_SUMMARY_FILENAME_EXT
from datagen.shared.file_lookup_service import \
    CaptoolClassificationFileLookupService
from datagen.shared.utility import clean_dir, \
    get_rop_session_through_system_time, increase_session, get_rop_sessions, \
    get_sleep_time_in_sec, ensure_dir, get_current_utc_time_in_seconds
from datagen.up_datagen.enricher import ClassificationEnricher
from datetime import datetime
from multiprocessing import queues
from multiprocessing.process import Process
import ConfigParser
import glob
import multiprocessing
import os
import subprocess
import sys
import time

'''
  The ClassificationGenerator copies files from master file repository to feed ClassificationEnricher in the enricher module
  
  To initialise a ClassificationGenerator object, a dictionary object containing the setting information 
  should be provided.
  
  The dictionary object may contain the following key/value pairs:
  nowait [True|False] (optional), default to False
         used for debug purpose in the realtime processing mode; this attribute indicates whether the running thread 
         should wait to process next rop
  noenrich [True|False] (optional), default to False,
         determine whether to enrich sgeh data or not; 
  clean [True|False] (optional), default to False,
         whether to clean the output directory first       
  output_base_directory
         this is the common prefix of output directory path of all data types
  output_subdirectory
         the actual folder under the output_base_directory that contains the copied classification files
  input_base_directory
         base directory of the master file repository, i.e., common prefix of the directory path of all data types
  input_subdirectory
         the actual directory under the input_base_directory contains the classification files
  realtime
         whether to generated data in realtime mode or dump mode
  rop_time_period
         indicates how long does the generator have to wait (minute based) in the realtime mode, 
         e.g., for classification records, rop_time_period is 1 minute
  rop_start
         used in dump mode only, indicates the rop start time, e.g., 201205161600 (2012-05-16 16:00)
  rop_end
         used in dump mode only, indicates the rop end time, e.g., 201205171600 (2012-05-17 16:00)
  number_of_probes
         number of probe replications
'''
class ClassificationGenerator(Process):

    def __init__(self, options):
        Process.__init__(self)
        self.__options = dict(options)
        datagen_logger.trace('%s options: %s', self.__class__.__name__, self.__options)
        self.__terminate_list = queues.Queue()
        self.__shutdown = False
                
    def run(self):
        self.generate(self.__options)
        
    def terminate(self):
        self.__shutdown = True
        while not self.__terminate_list.empty():
            enricher_pid = self.__terminate_list.get()
            subprocess.Popen(['pkill', '-P', str(enricher_pid)]).wait()
            subprocess.Popen(['kill', str(enricher_pid)]).wait()
        subprocess.Popen(['kill', str(self.pid)]).wait()
        
    # options should contain common fields shared by all type of data generator
    def generate(self, options):
        
        try:            
            nowait   = options['nowait'] if options.has_key('nowait') else False
            noenrich = options['noenrich'] if options.has_key('noenrich') else False
            clean    = options['clean'] if options.has_key('clean') else False
            
            props_filename = 'classification.props'
            if not os.path.exists(options['etc']+os.sep+props_filename):
                datagen_logger.error('configuration file %s does not exist', props_filename)
                
            config = ConfigParser.ConfigParser()
            config.readfp(open(options['etc']+os.sep+props_filename))
            
            lookup_timerange_start = config.get('basic', 'lookup_timerange_start').strip()
            if not lookup_timerange_start:
                datagen_logger.error('lookup start time required')
                sys.exit()        
            
            lookup_timerange_end   = config.get('basic', 'lookup_timerange_end').strip()
            if not lookup_timerange_end:
                datagen_logger.error('lookup end time required')
                sys.exit()
            
            realtime           = options['realtime']
            rop_start          = options['rop_start']
            rop_end            = options['rop_end']
            
            output_directory_options = config.options('output_directories')
            output_directories = []            
            for output_directory_option in output_directory_options:
                directory = config.get('output_directories', output_directory_option)
                if not directory.endswith(os.sep):
                    directory = ''.join([directory, os.sep])
                output_directories.append(directory)
            
            if len(output_directories) == 0:
                datagen_logger.error('no output directories specified in the classification configuration')
                sys.exit()
              
            '''
                set imsi enrichment option to each RNC 
            '''          
            if not config.has_section('imsi_enrichment_options'):
                datagen_logger.error('imsi_enrichment_options section is not defined in the props file')
                sys.exit()
            
            imsi_enrichment_options = {}            
            rncs = config.options('imsi_enrichment_options')
            for rnc in rncs:
                imsi_enrichment_options[rnc] = config.getboolean('imsi_enrichment_options', rnc)
            
            if datagen_logger.isTraceEnabled():
                for imsi_enrichment_option in imsi_enrichment_options:
                    datagen_logger.trace('imsi enrichment options: %s', imsi_enrichment_option)
                    
            '''
                set imsi option to each RNC 
            '''          
            if not config.has_section('imsi_options'):
                datagen_logger.error('imsi_options section is not defined in the props file')
                sys.exit()
            
            imsi_options = {}            
            rncs = config.options('imsi_options')
            for rnc in rncs:
                imsi_options[rnc] = config.get('imsi_options', rnc)
                
            if datagen_logger.isTraceEnabled():
                for imsi_option in imsi_options:
                    datagen_logger.trace('imsi options: %s', imsi_option)   
                
            '''
                set datetime enrichment option to each Probe node
            '''
            if not config.has_section('datetime_enrichment_options'):
                datagen_logger.error('datetime_enrichment_options section is not defined in the props file')
                sys.exit()
                
            datetime_enrichment_options = {}
            rncs = config.options('datetime_enrichment_options')
            for rnc in rncs:
                datetime_enrichment_options[rnc] = config.getboolean('datetime_enrichment_options', rnc)
            
            input_directory    = config.get('basic', 'input_directory')
            if not input_directory.endswith(os.sep):
                input_directory = ''.join([input_directory, os.sep])
            
            rop_time_period    = config.getint('basic', 'rop_time_period') 
            number_of_probes   = config.getint('basic', 'number_of_probes')
            enable_compression = config.getboolean('basic', 'enable_compression') if config.has_option('basic', 'enable_compression') else False
            
            rnc_mcc_mnc_lac_map = {}
            if not config.has_section('rnc_mcc_mnc_lac_map'):
                datagen_logger.error('rnc_mcc_mnc_lac_map section is not defined in the props file')
                sys.exit()

            rncs = config.options('rnc_mcc_mnc_lac_map')
            for rnc in rncs:
                rnc_mcc_mnc_lac_map[rnc] = config.get('rnc_mcc_mnc_lac_map', rnc)        
            
            if datagen_logger.isTraceEnabled():
                for item in rnc_mcc_mnc_lac_map.items():
                    datagen_logger.trace('rnc to mcc_mnc_lac mapping: %s', item)
                                        
        except: 
            datagen_logger.exception(sys.stderr)

        try:
            for output_directory in output_directories:
                ensure_dir(output_directory)
        except:
            datagen_logger.exception(sys.stderr)
                   
        if clean:
            for clean_directory in output_directories:
                datagen_logger.trace('clean output directory: %s', clean_directory)
                clean_dir(clean_directory, 'classification')   
                 
        '''
         the enrich_options list stores all parameters required by the enrich_classification() method 
         in the userplane_enrich module
        '''
        enrich_options = {};
        if options['enrich_imsi']:
            enrich_options['enrich_imsi'] = options['enrich_imsi']
            
        enrich_options['imsi_prefix']                 = options['imsi_prefix']        
        enrich_options['enrich_datetime']             = options['enrich_datetime']    
        enrich_options['number_of_probes']            = number_of_probes            
        enrich_options['output_directories']          = output_directories
        enrich_options['imsi_enrichment_options']     = imsi_enrichment_options
        enrich_options['datetime_enrichment_options'] = datetime_enrichment_options
        enrich_options['rnc_mcc_mnc_lac_map']         = rnc_mcc_mnc_lac_map
        enrich_options['imsi_options']                = imsi_options
        enrich_options['enable_compression']          = enable_compression
        
        datagen_logger.trace('enrichment options: %s', enrich_options)
                
        classification_file_lookup_service = CaptoolClassificationFileLookupService((lookup_timerange_start, lookup_timerange_end))
        
        try:    
            if realtime:
                
                if not nowait:                    
                    sleeptime = get_sleep_time_in_sec(datetime.utcnow(), rop_time_period)
                    datagen_logger.debug('%s sleep for %d', self.__class__.__name__, sleeptime)                
                    time.sleep(sleeptime)
                    
                session = get_rop_session_through_system_time(rop_time_period)
                         
                while True and not self.__shutdown:
                    
                    process_start_datetime = datetime.utcnow()
                    
                    '''
                        if last generation process spent more than two rop_period_time, then we 
                        need to reset the session time 
                    '''
                    diff_in_minutes = (process_start_datetime-session[1]).seconds / 60 - rop_time_period;
                    if diff_in_minutes >= 2*rop_time_period:
                        datagen_logger.error('last %s process took place %d seconds ago, skip %d rop(s)', 
                                      self.__class__.__name__, (process_start_datetime-session[1]).seconds, 
                                      diff_in_minutes/rop_time_period-1)
                        new_session = get_rop_session_through_system_time(rop_time_period);
                        datagen_logger.error('set session from %s, %s -->> %s, %s', str(session[0]), str(session[1]), 
                                                                            str(new_session[0]), str(new_session[1]))
                        session = new_session
                                                                                                          
                    datagen_logger.info('realtime classification file generation, current session: %s, %s', str(session[0]), str(session[1]))
                    filename_prefix = classification_file_lookup_service.get_captool_classification_filename_prefix(session[0], session[1])
                    
                    datagen_logger.debug("classification lookup service search pattern %s", filename_prefix)
                    
                    filematches = classification_file_lookup_service.find_captool_classification_file(input_directory, filename_prefix)
                    
                    if filematches:
                        datagen_logger.debug('find classification files [%s] starting with prefix [%s] in directory %s', 
                                             filematches, filename_prefix, input_directory) 
    
                        
                        tmp_date_in_str = str(session[0].year)
                        if session[0].month < 10:
                            tmp_date_in_str += '0'
                        tmp_date_in_str += str(session[0].month)
                        if session[0].day < 10:
                            tmp_date_in_str += '0'
                        tmp_date_in_str += str(session[0].day)
    
                        enrich_options['enriched_start_datetime_date'] = tmp_date_in_str
                        enrich_options['enriched_start_datetime_hour'] = session[0].hour
                        
                        tmp_date_in_str = str(session[1].year)
                        if session[1].month < 10:
                            tmp_date_in_str += '0'
                        tmp_date_in_str += str(session[1].month)
                        if session[1].day < 10:
                            tmp_date_in_str += '0'
                        tmp_date_in_str += str(session[1].day)
                            
                        enrich_options['enriched_end_datetime_date'] = tmp_date_in_str      
                        enrich_options['enriched_end_datetime_hour'] = session[1].hour
                        
                        if datagen_logger.isTraceEnabled():
                            for filematch in filematches:
                                metrics.log_statistic_info(datagen_logger, datagen_logging.TRACE, 
                                                           'file %s, size %.4f MB' % (filematch, os.path.getsize(filematch)/1024.0/1024.0))
                                    
                        if not noenrich:
                            start_time = get_current_utc_time_in_seconds()
                            datagen_logger.info('classification file regeneration for session %s, %s started', str(session[0]), str(session[1]))
                            enrich_options['input_files'] = filematches                            
                            enricher = ClassificationEnricher(enrich_options)                            
                            enricher.start()
                            self.__terminate_list.put(enricher.pid)                            
                            enricher.join()
                            self.__terminate_list.get()
                            end_time = get_current_utc_time_in_seconds()
                            datagen_logger.info('classification file regeneration finished with in %f seconds for %d PCPs, %d rncs of session %s, %s', 
                                         (end_time-start_time), number_of_probes, len(rnc_mcc_mnc_lac_map), str(session[0]), str(session[1]))
                    else:
                        datagen_logger.warning('no classification files matching search pattern %s', filename_prefix)
                                
                    session = (increase_session(session[0], rop_time_period),
                               increase_session(session[1], rop_time_period))
                    
                    process_end_datetime = datetime.utcnow()
                    
                    total_time_spend_in_minute = float((process_end_datetime-process_start_datetime).seconds)/60.0
                    
                    if total_time_spend_in_minute >= rop_time_period:
                        if total_time_spend_in_minute >= 2*rop_time_period:
                            datagen_logger.error('system is too busy, total time spend %f', total_time_spend_in_minute)
                        # no need to sleep
                        datagen_logger.debug('%s continue without sleep', self.__class__.__name__)
                        continue
                    
                    if not nowait:                    
                        sleeptime = get_sleep_time_in_sec(datetime.utcnow(), rop_time_period)
                        if sleeptime == 60 * rop_time_period:
                            time.sleep(5)
                            sleeptime = get_sleep_time_in_sec(datetime.utcnow(), rop_time_period)
                        datagen_logger.debug('%s sleep for %d', self.__class__.__name__, sleeptime)                
                        time.sleep(sleeptime)
            else:
                sessions = get_rop_sessions(rop_start, rop_end, rop_time_period)
                
                if sessions is not None:
                    start_time = get_current_utc_time_in_seconds()     
                    enrichers = []                       
                    datagen_logger.info('start classification file regeneration in dump mode')
                    for session in sessions:
                        
                        datagen_logger.info('classification file generation, current session: %s, %s', str(session[0]), str(session[1]))
                        
                        filename_prefix = classification_file_lookup_service.get_captool_classification_filename_prefix(session[0], session[1])
                        
                        datagen_logger.debug("classification lookup service search pattern %s", filename_prefix)
                        
                        filematches = classification_file_lookup_service.find_captool_classification_file(input_directory, filename_prefix)
                        
                        if filematches:
                            datagen_logger.debug('find classification files starting with prefix: %s, %s', filename_prefix,  filematches)
                            
                            tmp_date_in_str = str(session[0].year)
                            if session[0].month < 10:
                                tmp_date_in_str += '0'
                            tmp_date_in_str += str(session[0].month)
                            if session[0].day < 10:
                                tmp_date_in_str += '0'
                            tmp_date_in_str += str(session[0].day)
        
                            enrich_options['enriched_start_datetime_date'] = tmp_date_in_str
                            enrich_options['enriched_start_datetime_hour'] = session[0].hour
                            
                            tmp_date_in_str = str(session[1].year)
                            if session[1].month < 10:
                                tmp_date_in_str += '0'
                            tmp_date_in_str += str(session[1].month)
                            if session[1].day < 10:
                                tmp_date_in_str += '0'
                            tmp_date_in_str += str(session[1].day)
                                
                            enrich_options['enriched_end_datetime_date'] = tmp_date_in_str      
                            enrich_options['enriched_end_datetime_hour'] = session[1].hour
                            
                            if datagen_logger.isTraceEnabled():
                                for filematch in filematches:
                                    metrics.log_statistic_info(datagen_logger, datagen_logging.TRACE, 
                                                           'file %s, size %.4f MB' % (filematch, os.path.getsize(filematch)/1024.0/1024.0))
                            
                            if not noenrich:                                
                                enrich_options['input_files'] = filematches                         
                                enricher = ClassificationEnricher(enrich_options)
                                enrichers.append(enricher)
    
                                if len(enrichers) == multiprocessing.cpu_count():                            
                                    for enricher in enrichers:
                                        enricher.start()
                                        
                                    for enricher in enrichers:
                                        enricher.join()
                                        
                                    enrichers = []
                    
                    if not noenrich and len(enrichers) > 0:
                        for enricher in enrichers:
                            enricher.start()
                                            
                        for enricher in enrichers:
                            enricher.join()         
                        
                        enrichers = None
                        
                    end_time = get_current_utc_time_in_seconds()   
                    datagen_logger.info('classification file regeneration finished with in %f seconds for %d PCPs, %d rncs', (end_time-start_time), number_of_probes, len(rnc_mcc_mnc_lac_map))
        except:
            datagen_logger.exception(sys.stderr)
