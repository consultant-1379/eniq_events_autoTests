'''
Created on 23 Aug 2012

@author: epstvxj
'''
from datagen.settings import datagen_logger
from datagen.shared import metrics, datagen_logging
from datagen.shared.utility import ensure_dir
from datetime import datetime
from multiprocessing import queues
from multiprocessing.process import Process
from threading import Thread
import calendar
import csv
import os
import subprocess
import gzip
from shutil import move
    
class ClassificationEnricher(Process):
    
    def __init__(self, enrich_options):
        Process.__init__(self)
        self.__enrich_options = enrich_options
        self.__terminate_list = queues.Queue()
        
    def run(self):
        self.__enrich_classification()
    
    def terminate(self):
        datagen_logger.debug('number of subprocesses %d', self.__terminate_list.qsize())
        while not self.__terminate_list.empty():
            enricher_pid = self.__terminate_list.get()
            subprocess.Popen(['pkill', '-P', str(enricher_pid)]).wait()
            subprocess.Popen(['kill', str(enricher_pid)]).wait()
        subprocess.Popen(['pkill', '-P', str(self.pid)]).wait()    
        subprocess.Popen(['kill', str(self.pid)]).wait()
    
    def __enrich_classification(self):
        
        output_directories           = self.__enrich_options['output_directories']
        enrich_datetime              = self.__enrich_options['enrich_datetime']
        enrich_imsi                  = self.__enrich_options['enrich_imsi']
        enriched_start_datetime_date = self.__enrich_options['enriched_start_datetime_date']
        enriched_start_datetime_hour = self.__enrich_options['enriched_start_datetime_hour']
        enriched_end_datetime_hour   = self.__enrich_options['enriched_end_datetime_hour']
        input_files                  = self.__enrich_options['input_files']
        imsi_enrichment_options      = self.__enrich_options['imsi_enrichment_options']     
        datetime_enrichment_options  = self.__enrich_options['datetime_enrichment_options']
        rnc_mcc_mnc_lac_map          = self.__enrich_options['rnc_mcc_mnc_lac_map']
        number_of_probes             = self.__enrich_options['number_of_probes']
        imsi_options                 = self.__enrich_options['imsi_options']
        enable_compression           = self.__enrich_options['enable_compression']
        __subprocess_list            = []
        
        output_directories.sort()
        
        for input_file in input_files:
            input_filename = input_file[input_file.rindex(os.sep)+1:]
            
            output_filename = None
            if enrich_datetime or enrich_imsi:
                
                '''
                    the following code block obtains the new output file name according to the session time
                '''    
                if enrich_datetime:
                    index = input_filename.find('-A')              
                    original_date = input_filename[index+2:index+10]
                    index = input_filename.find('.')+1                    
                    original_starttime = input_filename[index:index+4]
                    index = input_filename.find('-', input_filename.find('-A')+1)+1
                    original_endtime = input_filename[index:index+4]
                    
                    new_date = datetime.strptime(enriched_start_datetime_date, "%Y%m%d")                                      
                    new_date_str = str(new_date.year)
                    if new_date.month < 10:
                        new_date_str += '0'
                    new_date_str += str(new_date.month)
                    if new_date.day < 10:
                        new_date_str += '0'
                    new_date_str += str(new_date.day)
                    
                    output_filename = input_filename.replace(original_date,new_date_str,1)
                                        
                    if enriched_start_datetime_hour < 10:
                        output_filename = output_filename.replace(original_starttime,'0'+str(enriched_start_datetime_hour)+original_starttime[2:])
                    else:
                        output_filename = output_filename.replace(original_starttime,str(enriched_start_datetime_hour)+original_starttime[2:])
                    
                    if enriched_end_datetime_hour < 10:
                        output_filename = output_filename.replace(original_endtime,'0'+str(enriched_end_datetime_hour)+original_endtime[2:])
                    else:
                        output_filename = output_filename.replace(original_endtime,str(enriched_end_datetime_hour)+original_endtime[2:])

                else: 
                    return
                
                __subprocess_list[:] = []
                rnc_mcc_mnc_lac_map_keys = rnc_mcc_mnc_lac_map.keys()

                for rnc_number_in_string in rnc_mcc_mnc_lac_map_keys:

                    mcc_mnc_lac = rnc_mcc_mnc_lac_map[rnc_number_in_string]
                    
                    abs_output_filenames = []
                    for output_directory in output_directories:
                        
                        '''
                          obtain the output directory storing RNC <rnc_number> traffic captured by Probe <probe_count> 
                        '''
                        current_output_directory = output_directory                        
                        if not current_output_directory.endswith(os.sep):
                            current_output_directory = ''.join([current_output_directory,os.sep])
                        current_output_directory = ''.join([current_output_directory,mcc_mnc_lac,os.sep])
                        ensure_dir(current_output_directory)
                        
                        abs_output_filename = None
                        if enrich_datetime and datetime_enrichment_options[rnc_number_in_string]:
                            # need to replace the mcc_mnc_lac prefix of the original filename with the new one
                            prefix_end_index = output_filename.find('-A')                            
                            abs_output_filename = ''.join([current_output_directory,mcc_mnc_lac,output_filename[prefix_end_index:]])
                        else:
                            abs_output_filename = current_output_directory+input_filename                        
                        
                        if enable_compression:
                            abs_output_filenames.append(''.join([abs_output_filename, '.gz']))
                        else:
                            abs_output_filenames.append(abs_output_filename)
                        
                        
                    enrich_datetime_for_current_probe = enrich_datetime & datetime_enrichment_options[rnc_number_in_string]
                    enrich_imsi_for_current_probe = enrich_imsi & imsi_enrichment_options[rnc_number_in_string]
                        
                    p = Process(target=self.__enriching, 
                                  args=(input_file, abs_output_filenames, mcc_mnc_lac,
                                        enrich_datetime_for_current_probe, enrich_imsi_for_current_probe, imsi_options[rnc_number_in_string], 
                                        rnc_number_in_string, number_of_probes))
                    
                    __subprocess_list.append(p)                       

                if len(__subprocess_list) > 0:
                    datagen_logger.info('%d enrichment jobs created by %s for %d PCP(s) and %d RNC(s)', 
                                        len(__subprocess_list), self.__class__.__name__, number_of_probes, len(rnc_mcc_mnc_lac_map))       
                    for job in __subprocess_list:
                        job.start()
                        self.__terminate_list.put(p.pid)
                    for job in __subprocess_list:
                        job.join()
                    while not self.__terminate_list.empty():
                        self.__terminate_list.get()
                 
    #end enrich_classification()
    
    def __enriching(self, input_file, abs_output_filenames, mcc_mnc_lac, enrich_datetime, enrich_imsi, new_imsi_prefix, rnc_number_in_string, number_of_probes):
        
        enriched_start_datetime_date = self.__enrich_options['enriched_start_datetime_date']
        enriched_start_datetime_hour = self.__enrich_options['enriched_start_datetime_hour']
        target_imsi_prefix           = self.__enrich_options['imsi_prefix']
        enriched_end_datetime_date   = self.__enrich_options['enriched_end_datetime_date']
        enriched_end_datetime_hour   = self.__enrich_options['enriched_end_datetime_hour']
        enable_compression           = self.__enrich_options['enable_compression']
        lac                          = mcc_mnc_lac.split('_')[2]
        
        enriched_fields_list = [[] for _index in range(number_of_probes)]
        
        line_count = 0
        
        with open(input_file, 'rb') as f:                                            
            for line in f:
                
                fields = line.strip().split("|")
                
                if enrich_datetime:
                    # original start time
                    start_timestamp = float(fields[1])
                    start_datetime = datetime.utcfromtimestamp(start_timestamp)                        
                    # original end time
                    end_timestamp = float(fields[2])
                    end_datetime = datetime.utcfromtimestamp(end_timestamp)
                    # time to enrich to     
                    enriched_datetime = datetime.strptime(enriched_start_datetime_date, "%Y%m%d")
                                   
                    
                    start_datetime = start_datetime.replace(year=enriched_datetime.year,
                                                            month=enriched_datetime.month,
                                                            day=enriched_datetime.day)
                
                    start_datetime = start_datetime.replace(hour=enriched_start_datetime_hour)
                         
                    enriched_datetime = datetime.strptime(enriched_end_datetime_date, "%Y%m%d")                                                
                    
                    end_datetime = end_datetime.replace(year=enriched_datetime.year,
                                                        month=enriched_datetime.month,
                                                        day=enriched_datetime.day)
                
                    end_datetime = end_datetime.replace(hour=enriched_end_datetime_hour)
                              
                    # TODO may be an alternative approach to set the floating point to 6 decimal points               
                    fields[1] = "{0:.6f}".format(float(calendar.timegm(start_datetime.timetuple())+start_datetime.microsecond/1e6));
                    fields[2] = "{0:.6f}".format(float(calendar.timegm(end_datetime.timetuple())+start_datetime.microsecond/1e6));
                    
                origin_imsi = fields[3]
                if enrich_imsi and origin_imsi.startswith(target_imsi_prefix):                        
                    origin_imsi_suffix = origin_imsi.replace(target_imsi_prefix,'',1)
                    origin_imsi = new_imsi_prefix + origin_imsi_suffix
                    fields[3] = origin_imsi
                    
                    cgi_fields = fields[8].split(':')
                    cgi_fields[2] = lac                    
                    fields[8] = ':'.join(cgi_fields)
                    
                    sai_fields = fields[9].split(':')
                    sai_fields[2] = lac                    
                    fields[9] = ':'.join(sai_fields)
                    
                    rai_fields = fields[10].split(':')
                    rai_fields[2] = lac                    
                    fields[10] = ':'.join(rai_fields)
                    
                enriched_fields_list[line_count % number_of_probes].append(fields)
                line_count += 1
        
        if abs_output_filenames:
            probe_number = 1    
            assert(len(abs_output_filenames)==len(enriched_fields_list))
            job_list = []  
            
            for abs_output_filename in abs_output_filenames:
                enriched_fields = enriched_fields_list.pop()
                
                path_components = abs_output_filename.split(os.sep)
                path_components[-1] = 'incomplete_' + path_components[-1]
                
                temp_abs_output_filename = os.sep + os.sep.join(path_components)
                
                if enable_compression:
                    writer = csv.writer(gzip.open(temp_abs_output_filename, 'wb+'), delimiter='|',quoting=csv.QUOTE_NONE)  
                else:
                    writer = csv.writer(open(temp_abs_output_filename, 'wb+'), delimiter='|',quoting=csv.QUOTE_NONE)
                    
                if datagen_logger.isTraceEnabled():
                    metrics.log_statistic_info(datagen_logger, datagen_logging.TRACE, 
                                               'total number of lines of file %s, [%d], number of lines stored by PCP %d for %s [%d]'% 
                                               (input_file, line_count, probe_number, rnc_number_in_string, len(enriched_fields)))
                
                if number_of_probes > 2:
                    job_list.append(Thread(target=lambda x,y: x.writerows(y), args=(writer, enriched_fields)))
                else:
                    writer.writerows(enriched_fields)
                
                probe_number += 1
            for job in job_list:
                job.start()
            for job in job_list:
                job.join()
                
            for abs_output_filename in abs_output_filenames:
                path_components = abs_output_filename.split(os.sep)
                path_components[-1] = 'incomplete_' + path_components[-1]
                
                temp_abs_output_filename = os.sep + os.sep.join(path_components)
                datagen_logger.trace('rename temp file %s to %s', temp_abs_output_filename, abs_output_filename)
                move(temp_abs_output_filename, abs_output_filename)
                
class TcpPartialEnricher(Process):
    
    def __init__(self, enrich_options):
        Process.__init__(self)
        self.__enrich_options = enrich_options
        self.__terminate_list = queues.Queue()
        
    def run(self):
        self.__enrich_tcp_partial()
    
    def terminate(self):
        while not self.__terminate_list.empty():
            enricher_pid = self.__terminate_list.get()
            subprocess.Popen(['pkill', '-P', str(enricher_pid)]).wait()
            subprocess.Popen(['kill', str(enricher_pid)]).wait()
        subprocess.Popen(['pkill', '-P', str(self.pid)]).wait()
        subprocess.Popen(['kill', str(self.pid)]).wait()
    
    def __enrich_tcp_partial(self):
     
        output_directories           = self.__enrich_options['output_directories']
        enrich_datetime              = self.__enrich_options['enrich_datetime']
        enrich_imsi                  = self.__enrich_options['enrich_imsi']
        enriched_start_datetime_date = self.__enrich_options['enriched_start_datetime_date']
        enriched_start_datetime_hour = self.__enrich_options['enriched_start_datetime_hour']
        enriched_end_datetime_hour   = self.__enrich_options['enriched_end_datetime_hour']
        input_files                  = self.__enrich_options['input_files']
        imsi_enrichment_options      = self.__enrich_options['imsi_enrichment_options']     
        datetime_enrichment_options  = self.__enrich_options['datetime_enrichment_options']
        rnc_mcc_mnc_lac_map          = self.__enrich_options['rnc_mcc_mnc_lac_map']        
        number_of_probes             = self.__enrich_options['number_of_probes']
        imsi_options                 = self.__enrich_options['imsi_options']
        enable_compression           = self.__enrich_options['enable_compression']
        __subprocess_list            = []
        
        output_directories.sort()
        
        for input_file in input_files:
            input_filename = input_file[input_file.rindex(os.sep)+1:]
    
            output_filename = None
            if enrich_datetime or enrich_imsi:
                
                '''
                    the following code block obtains the new output file name according to the session time
                '''
                if enrich_datetime:      
                    index = input_filename.find('-A')              
                    original_date = input_filename[index+2:index+10]
                    index = input_filename.find('.')+1                    
                    original_starttime = input_filename[index:index+4]
                    index = input_filename.find('-', input_filename.find('-A')+1)+1
                    original_endtime = input_filename[index:index+4]
                    
                    new_date = datetime.strptime(enriched_start_datetime_date, "%Y%m%d")
                    new_date_str = str(new_date.year)
                    if new_date.month < 10:
                        new_date_str += '0'
                    new_date_str += str(new_date.month)
                    if new_date.day < 10:
                        new_date_str += '0'
                    new_date_str += str(new_date.day)
                    
                    output_filename = input_filename.replace(original_date,new_date_str,1)
                                        
                    if enriched_start_datetime_hour < 10:
                        output_filename = output_filename.replace(original_starttime,'0'+str(enriched_start_datetime_hour)+original_starttime[2:])
                    else:
                        output_filename = output_filename.replace(original_starttime,str(enriched_start_datetime_hour)+original_starttime[2:])
                    
                    if enriched_end_datetime_hour < 10:
                        output_filename = output_filename.replace(original_endtime,'0'+str(enriched_end_datetime_hour)+original_endtime[2:])
                    else:
                        output_filename = output_filename.replace(original_endtime,str(enriched_end_datetime_hour)+original_endtime[2:])
                
                                            
                else: 
                    return
                  
                __subprocess_list[:] = []
                rnc_mcc_mnc_lac_map_keys = rnc_mcc_mnc_lac_map.keys()

                for rnc_number_in_string in rnc_mcc_mnc_lac_map_keys:

                    mcc_mnc_lac = rnc_mcc_mnc_lac_map[rnc_number_in_string]
                    
                    abs_output_filenames = []
                    for output_directory in output_directories:
                        
                        '''
                          obtain the output directory storing RNC <rnc_number> traffic captured by Probe <probe_count> 
                        '''
                        current_output_directory = output_directory                        
                        if not current_output_directory.endswith(os.sep):
                            current_output_directory = ''.join([current_output_directory,os.sep])
                        current_output_directory = ''.join([current_output_directory,mcc_mnc_lac,os.sep])
                        ensure_dir(current_output_directory)
                        
                        if enrich_datetime and datetime_enrichment_options[rnc_number_in_string]:
                            # need to replace the mcc_mnc_lac prefix of the original filename with the new one
                            prefix_end_index = output_filename.find('-A')                            
                            abs_output_filename = ''.join([current_output_directory,mcc_mnc_lac,output_filename[prefix_end_index:]])
                        else:
                            abs_output_filename = current_output_directory+input_filename                        
                        
                        if enable_compression:
                            abs_output_filenames.append(''.join([abs_output_filename, '.gz']))
                        else:
                            abs_output_filenames.append(abs_output_filename)
                        
                    enrich_datetime_for_current_probe = enrich_datetime & datetime_enrichment_options[rnc_number_in_string]
                    enrich_imsi_for_current_probe = enrich_imsi & imsi_enrichment_options[rnc_number_in_string]
                        
                    p = Process(target=self.__enriching, 
                                  args=(input_file, abs_output_filenames, mcc_mnc_lac,
                                        enrich_datetime_for_current_probe, enrich_imsi_for_current_probe, imsi_options[rnc_number_in_string], 
                                        rnc_number_in_string, number_of_probes))
                    #p.daemon = True
                    __subprocess_list.append(p)
                
                if len(__subprocess_list) > 0:
                    datagen_logger.info('%d enrichment jobs created by %s for %d PCP(s) and %d RNC(s)', 
                                        len(__subprocess_list), self.__class__.__name__, number_of_probes, len(rnc_mcc_mnc_lac_map))
                    for job in __subprocess_list:
                        job.start()
                        self.__terminate_list.put(p.pid)
                    for job in __subprocess_list:                    
                        job.join()                    
                    while not self.__terminate_list.empty():
                        self.__terminate_list.get()
                    
    #end enrich_tcp_partial()
    
    def __enriching(self, input_file, abs_output_filenames, mcc_mnc_lac, enrich_datetime, enrich_imsi, new_imsi_prefix, rnc_number_in_string, number_of_probes):
        
        enriched_start_datetime_date = self.__enrich_options['enriched_start_datetime_date']
        enriched_start_datetime_hour = self.__enrich_options['enriched_start_datetime_hour']
        target_imsi_prefix           = self.__enrich_options['imsi_prefix']
        enable_compression           = self.__enrich_options['enable_compression']
        lac                          = mcc_mnc_lac.split('_')[2]
            
        line_count = 0
        enriched_fields_list = [[] for _index in range(number_of_probes)]
        
        with open(input_file, 'rb') as f:        
            for line in f:

                # 0 start time; 28 LAC 32 imsi
                fields = line.strip().split("\t")
                if enrich_datetime:
                    # original start time                        
                    start_timestamp = float(fields[0])
                    start_datetime = datetime.utcfromtimestamp(start_timestamp)
                    
                    # time to enrich to     
                    enriched_datetime = datetime.strptime(enriched_start_datetime_date, "%Y%m%d")
                                        
                    start_datetime = start_datetime.replace(year=enriched_datetime.year,
                                                            month=enriched_datetime.month,
                                                            day=enriched_datetime.day)
                
                    start_datetime = start_datetime.replace(hour=enriched_start_datetime_hour)
                                                      
                    # TODO may be an alternative approach to set the floating point to 6 decimal points               
                    fields[0] = "{0:.6f}".format(float(calendar.timegm(start_datetime.timetuple())+start_datetime.microsecond/1e6))
                
                if len(fields) > 32:
                    origin_imsi = fields[32]
                    if enrich_imsi and origin_imsi.startswith(target_imsi_prefix):
                                                       
                        origin_imsi = origin_imsi.replace(target_imsi_prefix,'',1)
                        origin_imsi = new_imsi_prefix + origin_imsi
                        fields[32] = origin_imsi
                        fields[28] = lac                                       
                    
                enriched_fields_list[line_count % number_of_probes].append(fields)
                line_count += 1
        
        if abs_output_filenames:
            probe_number = 1    
            assert(len(abs_output_filenames)==len(enriched_fields_list))
            job_list = []  
            for abs_output_filename in abs_output_filenames:
                enriched_fields = enriched_fields_list.pop()                
                
                path_components = abs_output_filename.split(os.sep)
                path_components[-1] = 'incomplete_' + path_components[-1]
                
                temp_abs_output_filename = os.sep + os.sep.join(path_components)
                
                if enable_compression:
                    writer = csv.writer(gzip.open(temp_abs_output_filename, 'wb+'), delimiter='\t',quoting=csv.QUOTE_NONE)  
                else:
                    writer = csv.writer(open(temp_abs_output_filename, 'wb+'), delimiter='\t',quoting=csv.QUOTE_NONE)
                                                        
                if datagen_logger.isTraceEnabled():
                    metrics.log_statistic_info(datagen_logger, datagen_logging.TRACE, 
                                               'total number of lines of file %s, [%d], number of lines stored by PCP %d for %s [%d]'% 
                                               (input_file, line_count, probe_number, rnc_number_in_string, len(enriched_fields)))
                if number_of_probes > 2:
                    job_list.append(Thread(target=lambda x,y: x.writerows(y), args=(writer, enriched_fields)))
                else:
                    writer.writerows(enriched_fields)
                probe_number += 1
            for job in job_list:
                job.start()
            for job in job_list:
                job.join()
            
            for abs_output_filename in abs_output_filenames:
                path_components = abs_output_filename.split(os.sep)
                path_components[-1] = 'incomplete_' + path_components[-1]
                
                temp_abs_output_filename = os.sep + os.sep.join(path_components)
                datagen_logger.trace('rename temp file %s to %s', temp_abs_output_filename, abs_output_filename)
                move(temp_abs_output_filename, abs_output_filename)
                
            
                
