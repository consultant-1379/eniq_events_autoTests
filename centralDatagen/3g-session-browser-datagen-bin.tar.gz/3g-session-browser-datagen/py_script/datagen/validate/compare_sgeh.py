'''
Created on Sep 18, 2012

@author: epstvxj
'''
from datagen.settings import datagen_logger
from datagen.shared.constants import SGEH_ERROR_RECORD, SGEH_FOOTER_RECORD, \
    SGEH_EVENT_RECORD, SGEH_EVENT_RAU, SGEH_EVENT_ATTACH, SGEH_EVENT_ACTIVATE, \
    SGEH_EVENT_ISRAU, SGEH_EVENT_DEACTIVATE, SGEH_EVENT_DETACH, \
    SGEH_EVENT_SERVICE_REQUEST
from datagen.shared.data_utility import validate_imsi, get_imsi
from struct import unpack
import os


def compare_sgeh_data(original_file, enriched_file, expected_datetime, enriched_imsi_prefix, original_imsi_prefix):
    
    if not os.path.exists(original_file):
        datagen_logger.error('original file %s does not exist', original_file)
        return
    if not os.path.exists(original_file):
        datagen_logger.error('enriched file %s does not exist', enriched_file)
        return
    
    f_original = open(original_file, 'rb')
    f_enriched = open(enriched_file, 'rb')
    
    try:
        
        original_bytes = f_original.read(12)
        enriched_bytes = f_enriched.read(12)
        
        if not check_header_record(original_bytes, enriched_bytes, expected_datetime):
            return
        
        original_bytes = f_original.read(2)
        enriched_bytes = f_enriched.read(2)
        while original_bytes:
            original_record_length = get_record_length(original_bytes)
            enriched_record_length = get_record_length(enriched_bytes)
            
            if original_record_length != enriched_record_length:
                datagen_logger.error('record length doest not match %d != %d', original_record_length, enriched_record_length)
                break
            
            original_bytes = f_original.read(1)
            enriched_bytes = f_enriched.read(1)
            
            original_record_type = get_event_type(original_bytes)
            enriched_record_type = get_event_type(enriched_bytes)
            
            if original_record_type != enriched_record_type:
                datagen_logger.error('record type does not match, %d != %d', original_record_type, enriched_record_type)
                break
            
            if original_record_type == SGEH_ERROR_RECORD:
                original_bytes = f_original.read(5)
                enriched_bytes = f_enriched.read(5)
                if original_bytes != enriched_bytes:
                    datagen_logger.error('error record content does not match')
                    break;
            elif original_record_type == SGEH_FOOTER_RECORD:
                original_bytes = f_original.read(1)
                enriched_bytes = f_enriched.read(1)
                if original_bytes != enriched_bytes:
                    datagen_logger.error('footer record content does not match')
                    break;
            elif original_record_type == SGEH_EVENT_RECORD:
                original_bytes = f_original.read(original_record_length-3)
                enriched_bytes = f_enriched.read(enriched_record_length-3)
                
                original_byte_list = unpack(''.join(['>',str(original_record_length-3),'B']), original_bytes)
                enriched_byte_list = unpack(''.join(['>',str(enriched_record_length-3),'B']), enriched_bytes)
                
                original_event_id = original_byte_list[0] 
                enriched_event_id = enriched_byte_list[0]
                
                if original_event_id != enriched_event_id:
                    datagen_logger.error('event id does not match, %d != %d', original_event_id, enriched_event_id)
                    break;
                
                byte_index = 0
                for original_byte in original_bytes:
                    if original_byte != original_bytes[byte_index]:
                        datagen_logger.error('bytes at offset %d does not match for event %d', byte_index, original_event_id)
                    byte_index += 1
                
                # byte offset of imsi
                offset = 0    
                if original_event_id == SGEH_EVENT_RAU:                                                           
                    offset = 134                    
                elif original_event_id == SGEH_EVENT_ATTACH:
                    offset = 133
                elif original_event_id == SGEH_EVENT_ACTIVATE:
                    offset = 135
                elif original_event_id == SGEH_EVENT_ISRAU:
                    offset = 133
                elif original_event_id == SGEH_EVENT_DEACTIVATE:
                    offset = 134                                            
                elif original_event_id == SGEH_EVENT_DETACH:
                    offset = 165
                elif original_event_id == SGEH_EVENT_SERVICE_REQUEST:
                    offset = 173
                
                original_imsi_bytearray = get_imsi(offset, original_byte_list)
                enriched_imsi_bytearray = get_imsi(offset, enriched_byte_list)

                validate_imsi(original_imsi_bytearray, enriched_imsi_bytearray, enriched_imsi_prefix, original_imsi_prefix, original_event_id)
                                            
            original_bytes = f_original.read(2)
            enriched_bytes = f_enriched.read(2)
        
    finally:
        f_original.close()
        f_enriched.close()

def get_event_type(data_in_bytes):
    byte_list = unpack('B', data_in_bytes)
    
    if byte_list[0] == 1:
        return SGEH_EVENT_RECORD
    elif byte_list[0] == 2:
        return SGEH_ERROR_RECORD
    elif byte_list[0] == 3:
        return SGEH_FOOTER_RECORD

def get_record_length(data_in_bytes):
    byte_list = unpack('2B', data_in_bytes)
    record_length = byte_list[0] << 8
    record_length |= byte_list[1]

    return record_length

def check_header_record(original_bytes, enriched_bytes, expected_datetime):   
    
    is_correct = True
    
    original_byte_list = unpack('12B', original_bytes)
 
    original_year = original_byte_list[5] << 8
    original_year |= original_byte_list[6]
    
    enriched_byte_list = unpack('12B', enriched_bytes)
    enriched_year = enriched_byte_list[5] << 8
    enriched_year |= enriched_byte_list[6]
    enriched_month = enriched_byte_list[7]
    enriched_day = enriched_byte_list[8]
    
    for index in range(12):
        if (index != 5 and index !=6 and index !=7 and index !=8):
            if original_byte_list[index] != enriched_byte_list[index]:
                datagen_logger.error('byte at position %d in head record does not match %s != %s', 
                              index, original_byte_list[index], enriched_byte_list[index])
                is_correct = False
    if expected_datetime.year != enriched_year:
        datagen_logger.error('expected year %d does not match the enriched year %d', expected_datetime.year, enriched_year)
        is_correct = False
    if expected_datetime.month != enriched_month:
        datagen_logger.error('expected month %d does not match the enriched month %d', expected_datetime.month, enriched_month)
        is_correct = False
    if expected_datetime.day != enriched_day:
        datagen_logger.error('expected day %d does not match to enriched day %d', expected_datetime.day, enriched_day)
        is_correct = False
        
    return is_correct
