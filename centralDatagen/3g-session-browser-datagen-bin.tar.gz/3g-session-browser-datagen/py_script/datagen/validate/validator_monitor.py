'''
Created on Sep 28, 2012

@author: epstvxj
'''
from datagen.settings import datagen_logger
from datagen.shared.utility import find_sgeh_match_file, get_expected_datetime, \
    find_staple_and_captool_file    
from datagen.validate.validator import SgehValidator, GpehValidator,\
    TcpPartialValidator, ClassificationlValidator
import os
import sys
import time
from datagen.validate.compare_gpeh import find_mp0_files,\
    get_number_of_rop_files, get_prefix, get_match_files,\
    get_prefix_with_no_date_and_rnc_info
import logging
from multiprocessing.process import Process
from ConfigParser import ConfigParser

class GpehValidatorMonitor(Process):
    
    def __init__(self, options):
        Process.__init__(self)
        configuration_filename = 'gpeh_validator.props'        
        if os.path.exists(options['etc']+os.sep+configuration_filename):  
            gpeh_validator_monitor_config = ConfigParser()
            gpeh_validator_monitor_config.readfp(open(options['etc']+os.sep+configuration_filename))
            
            self.__options = dict()
            self.__options['input_directory_path'] = gpeh_validator_monitor_config.get('basic', 'input_directory_path')
            self.__options['number_of_rncs']       = gpeh_validator_monitor_config.getint('basic', 'number_of_rncs')
            self.__options['remove_after_compare'] = gpeh_validator_monitor_config.getboolean('basic', 'remove_after_compare')
            self.__options['enriched_prefix']      = gpeh_validator_monitor_config.getint('basic', 'enriched_prefix')
            self.__options['original_prefix']      = gpeh_validator_monitor_config.getint('basic', 'original_prefix')
            self.__options['wait_time']            = gpeh_validator_monitor_config.getint('basic', 'wait_time')
            self.__options['nowait']               = options['nowait']
            
            output_directory_options = gpeh_validator_monitor_config.options('output_directories')
            output_directories = []
            for output_directory_option in output_directory_options:
                directory = gpeh_validator_monitor_config.get('output_directories', output_directory_option)
                if not directory.endswith(os.sep):
                    directory = ''.join([directory, os.sep])
                output_directories.append(directory)            
            self.__options['output_directories'] = output_directories
            
            datagen_logger.trace('%s options: %s', self.__class__.__name__, self.__options)
        else:
            datagen_logger.error('%s file does not exist in folder %s', configuration_filename, options['etc'])
        
    def run(self):
        
        '''
         The nowait attribute is used for testing purpose only.
         It is not defined in the property file.
         If one would like to use this attribute, then it has to be manually added into the option dictionary object passed
         to the __init__ constructor
        '''
        nowait = bool(self.__options['nowait']) if self.__options.has_key('nowait') else False
        waittime = int(self.__options['wait_time']) if self.__options.has_key('wait_time') else 1
        
        try:       
                         
            while True:     
                if not nowait:
                    time.sleep(waittime*60)
                           
                self.__validate()
                
        except:
            datagen_logger.error("error during gpeh file validation")
            sys.exit()
    
    def __validate(self):
        
        output_directories = None
        input_directory_path = None
        remove_after_compare = None
        original_prefix = None
        enriched_prefix = None
        
        if self.__options.has_key('output_directories') :
            output_directories = self.__options['output_directories'] 
        else:
            datagen_logger.error('no output_directories found in the option')
            sys.exit()
        
        if self.__options.has_key('input_directory_path') :
            input_directory_path = self.__options['input_directory_path'] 
        else:
            datagen_logger.error('no input_directory_path found in the option')
            sys.exit()
        
        if self.__options.has_key('remove_after_compare') :
            remove_after_compare = self.__options['remove_after_compare'] 
        else:
            datagen_logger.error('no remove_after_compare found in the option')
            sys.exit()
        
        if self.__options.has_key('original_prefix') :
            original_prefix = self.__options['original_prefix'] 
        else:
            datagen_logger.error('no original_prefix found in the option')
            sys.exit()
        
        if self.__options.has_key('enriched_prefix') :
            enriched_prefix = self.__options['enriched_prefix'] 
        else:
            datagen_logger.error('no enriched_prefix found in the option')
            sys.exit()
            
        to_validate = self.__options['to_validate'] if self.__options.has_key('to_validate') else True    
            
        output_directories.sort()        
        rnc_number = 0
        for output_directory in output_directories:
            rnc_number += 1
            if not output_directory.endswith(os.sep):
                output_directory = ''.join([output_directory, os.sep])
                
            expected_imsi_prefix = 0
        
            if rnc_number == 9: # RNC09
                expected_imsi_prefix = original_prefix
            elif rnc_number == 1:
                expected_imsi_prefix = enriched_prefix
            else:
                enriched_prefix += 1
                expected_imsi_prefix = enriched_prefix
            
            if not os.path.exists(output_directory):
                datagen_logger.warning('output directory does not exist [%s]', output_directory)
                continue
            
            mp0_files = find_mp0_files(output_directory)
            
            if mp0_files is None or len(mp0_files) == 0:
                datagen_logger.warning('cannot find mp0 file in %s', output_directory)
                continue
            
            for mp0_file in mp0_files:    
                
                validators = []
                
                number_of_expected_rop_files = get_number_of_rop_files(mp0_file)
                
                prefix = get_prefix(mp0_file)
                
                enriched_files = get_match_files(prefix, output_directory)
                
                if number_of_expected_rop_files != len(enriched_files):
                    datagen_logger.warning('mp0 file [%s] found, but not all rop files are available in %s', mp0_file, output_directory)
                    continue
                
                prefix_with_no_date_info = get_prefix_with_no_date_and_rnc_info(mp0_file)
                original_files = get_match_files(prefix_with_no_date_info, input_directory_path)
            
                if original_files == None or len(original_files) == 0:
                    datagen_logger.warning('match files does not found in %s for prefix %s', input_directory_path, prefix_with_no_date_info)
                    continue
                
                expected_datetime = get_expected_datetime(enriched_files[0])
                datagen_logger.debug('expected datetime %s of RNC %d', expected_datetime, rnc_number)
                
                validator_options = dict()
                
                validator_options['original_files']       = original_files
                validator_options['enriched_files']       = enriched_files
                validator_options['expected_datetime']    = expected_datetime
                validator_options['enriched_imsi_prefix'] = expected_imsi_prefix
                validator_options['original_imsi_prefix'] = original_prefix
                validator_options['remove_after_compare'] = remove_after_compare 
                
                validator = None
                if to_validate:
                    validator = GpehValidator(validator_options)
                    validators.append(validator)
                
                if datagen_logger.isEnabledFor(logging.DEBUG):
                    datagen_logger.debug('-----------------------------------------------------------------')
                    if to_validate:
                        datagen_logger.debug('validator name %s', validator.name)
                    
                    datagen_logger.debug('original files:')
                    for original_file in validator_options['original_files']:
                        datagen_logger.debug('%s', original_file)
                        
                    datagen_logger.debug('enriched files:')
                    for enriched_file in validator_options['enriched_files']:
                        datagen_logger.debug('%s', enriched_file)
                        
                    datagen_logger.debug('expected datetime %s', validator_options['expected_datetime'])
                    datagen_logger.debug('enriched imsi prefix %s', validator_options['enriched_imsi_prefix'])
                    datagen_logger.debug('original imsi prefix %s', validator_options['original_imsi_prefix'])
                    datagen_logger.debug('remove after compare %s', validator_options['remove_after_compare'])
                    datagen_logger.debug('-----------------------------------------------------------------\n')
            
                if to_validate:
                    for validator in validators:
                        validator.start()
                    
                    for validator in validators:
                        validator.join()
    

class SgehValidatorMointor(Process):
    
    def __init__(self, options):
        Process.__init__(self)
        configuration_filename = 'sgeh_validator.props'        
        if os.path.exists(options['etc']+os.sep+configuration_filename):
            sgeh_validator_monitor_config = ConfigParser()
            sgeh_validator_monitor_config.readfp(open(options['etc']+os.sep+configuration_filename))
            
            self.__options = dict()    
            self.__options['input_directory_path'] = sgeh_validator_monitor_config.get('basic', 'input_directory_path')                   
            self.__options['remove_after_compare'] = sgeh_validator_monitor_config.getboolean('basic', 'remove_after_compare')
            self.__options['original_prefix'] = sgeh_validator_monitor_config.getint('basic', 'original_prefix')
            self.__options['wait_time'] = sgeh_validator_monitor_config.getint('basic', 'wait_time')
            self.__options['nowait'] = options['nowait']
            
            output_directory_options = sgeh_validator_monitor_config.options('output_directories')
            output_directories = []
            expected_imsi_prefixes = {}
            datetime_enrichment_options = {}
            for output_directory_option in output_directory_options:
                directory = sgeh_validator_monitor_config.get('output_directories', output_directory_option)
                if not directory.endswith(os.sep):
                    directory = ''.join([directory, os.sep])
                output_directories.append(directory)                  

                if sgeh_validator_monitor_config.has_option('expected_imsi_prefixes', output_directory_option):
                    expected_imsi_prefixes[directory] = sgeh_validator_monitor_config.get('expected_imsi_prefixes', output_directory_option)
                else:
                    expected_imsi_prefixes[directory] = None
                
                if sgeh_validator_monitor_config.has_option('datetime_enrichment_options', output_directory_option):
                    datetime_enrichment_options[directory] = sgeh_validator_monitor_config.getboolean('datetime_enrichment_options', output_directory_option)
                else:
                    datetime_enrichment_options[directory] = False
                
            self.__options['datetime_enrichment_options'] = datetime_enrichment_options
            self.__options['expected_imsi_prefixes'] = expected_imsi_prefixes
            self.__options['output_directories'] = output_directories
            
            datagen_logger.trace('%s options: %s', self.__class__.__name__, self.__options)
                
        else:
            datagen_logger.error('%s file does not exist in folder %s', configuration_filename, options['etc'])        
        
    def run(self):
        
        '''
         The nowait attribute is used for testing purpose only.
         It is not defined in the property file.
         If one would like to use this attribute, then it has to be manually added into the option dictionary object passed
         to the __init__ constructor
        '''
        nowait = bool(self.__options['nowait']) if self.__options.has_key('nowait') else False
        waittime = int(self.__options['wait_time']) if self.__options.has_key('wait_time') else 1
        
        try:       
                         
            while True:     
                if not nowait:
                    time.sleep(waittime*60)
                           
                self.__validate()
                
        except:
            datagen_logger.error("error during sgeh file validation")
            sys.exit()
    
    def __validate(self):
        output_directories = None
        input_directory_path = None
        remove_after_compare = None
        original_prefix = None
        datetime_enrichment_options = None
        expected_imsi_prefixes = None
        
        if self.__options.has_key('output_directories') :
            output_directories = self.__options['output_directories'] 
        else:
            datagen_logger.error('no output_directories found in the option')
            sys.exit()
        
        if self.__options.has_key('input_directory_path') :
            input_directory_path = self.__options['input_directory_path'] 
        else:
            datagen_logger.error('no input_directory_path found in the option')
            sys.exit()
        
        if self.__options.has_key('remove_after_compare') :
            remove_after_compare = self.__options['remove_after_compare'] 
        else:
            datagen_logger.error('no remove_after_compare found in the option')
            sys.exit()
        
        if self.__options.has_key('original_prefix') :
            original_prefix = self.__options['original_prefix'] 
        else:
            datagen_logger.error('no original_prefix found in the option')
            sys.exit()
        
        if self.__options.has_key('datetime_enrichment_options') :
            datetime_enrichment_options = self.__options['datetime_enrichment_options'] 
        else:
            datagen_logger.error('no datetime_enrichment_options found in the option')
            sys.exit()
            
        if self.__options.has_key('expected_imsi_prefixes') :
            expected_imsi_prefixes = self.__options['expected_imsi_prefixes'] 
        else:
            datagen_logger.error('no expected_imsi_prefixes found in the option')
            sys.exit()
        to_validate                 = self.__options['to_validate'] if self.__options.has_key('to_validate') else True
                        
        output_directories.sort()    
        sgsn_number =  0
        for output_directory in output_directories:
            sgsn_number +=  1
            
            enrich_datetime = datetime_enrichment_options[output_directory] if datetime_enrichment_options.has_key(output_directory) else None
            if enrich_datetime is None:
                datagen_logger.error('no value found in the datetime_enrichment_options for key %s in %s', output_directory, self.__class__.__name__)             
            expected_imsi_prefix = expected_imsi_prefixes[output_directory] if expected_imsi_prefixes.has_key(output_directory) else None
            if expected_imsi_prefix is None:
                datagen_logger.error('no value found in the expected_imsi_prefix for key %s in %s', output_directory, self.__class__.__name__)
            
            if not output_directory.endswith(os.sep):
                output_directory = ''.join([output_directory, os.sep])

            if not os.path.exists(output_directory):
                datagen_logger.warning('output directory does not exist [%s]', output_directory)
                continue
            
            for generated_file in os.listdir(output_directory):
                
                validators = []
                
                original_file = find_sgeh_match_file(generated_file, input_directory_path)
                
                if original_file == None:
                    datagen_logger.warning('no match file %s found in %s', generated_file, input_directory_path)
                    continue
                
                expected_datetime = None
                if enrich_datetime:
                    expected_datetime = get_expected_datetime(generated_file)
                else:
                    expected_datetime = get_expected_datetime(original_file)
                    
                datagen_logger.debug('expected datetime %s of SGSN %d', expected_datetime, sgsn_number)
                
                validator_options = dict()
                
                validator_options['original_file_path']   = original_file
                validator_options['enriched_file_path']   = ''.join([output_directory,generated_file])
                validator_options['expected_datetime']    = expected_datetime
                validator_options['enriched_imsi_prefix'] = expected_imsi_prefix
                validator_options['original_imsi_prefix'] = original_prefix
                validator_options['remove_after_compare'] = remove_after_compare 
                
                validator = None
                if to_validate:
                    validator = SgehValidator(validator_options)
                    validators.append(validator)
                
                if datagen_logger.isEnabledFor(logging.DEBUG):
                    datagen_logger.debug('-----------------------------------------------------------------')
                    if to_validate:
                        datagen_logger.debug('validator name %s', validator.name)
                    datagen_logger.debug('original file path %s', validator_options['original_file_path'])
                    datagen_logger.debug('enriched file path %s', validator_options['enriched_file_path'])
                    datagen_logger.debug('expected datetime %s', validator_options['expected_datetime'])
                    datagen_logger.debug('enriched imsi prefix %s', validator_options['enriched_imsi_prefix'])
                    datagen_logger.debug('original imsi prefix %s', validator_options['original_imsi_prefix'])
                    datagen_logger.debug('remove after compare %s', validator_options['remove_after_compare'])
                    datagen_logger.debug('-----------------------------------------------------------------\n')
            
                if to_validate:    
                    for validator in validators:
                        validator.start()
                    
                    for validator in validators:
                        validator.join()
                            
class TcpPartialValidatorMointor(Process):
    
    def __init__(self, options):
        Process.__init__(self)
        configuration_filename = 'tcp_partial_validator.props'
        
        if os.path.exists(options['etc']+os.sep+configuration_filename):            
            tcp_partial_validator_monitor_config = ConfigParser()
            tcp_partial_validator_monitor_config.readfp(open(options['etc']+os.sep+configuration_filename))
            
            self.__options = dict()
            self.__options['input_directory_path'] = tcp_partial_validator_monitor_config.get('basic', 'input_directory_path')
            self.__options['remove_after_compare'] = tcp_partial_validator_monitor_config.getboolean('basic', 'remove_after_compare')
            self.__options['original_prefix']      = tcp_partial_validator_monitor_config.getint('basic', 'original_prefix')
            self.__options['wait_time']            = tcp_partial_validator_monitor_config.getint('basic', 'wait_time')
            self.__options['number_of_probes']     = tcp_partial_validator_monitor_config.getint('basic', 'number_of_probes')
            self.__options['nowait']               = options['nowait']
            
            output_directory_options = tcp_partial_validator_monitor_config.options('output_directories')
            output_directories = []
            expected_imsi_prefixes = {}
            datetime_enrichment_options = {}
            probe_numbers = {}
            for output_directory_option in output_directory_options:
                directory = tcp_partial_validator_monitor_config.get('output_directories', output_directory_option)
                if not directory.endswith(os.sep):
                    directory = ''.join([directory, os.sep])
                output_directories.append(directory)    
                if tcp_partial_validator_monitor_config.has_option('expected_imsi_prefixes', output_directory_option):
                    expected_imsi_prefixes[directory] = tcp_partial_validator_monitor_config.get('expected_imsi_prefixes', output_directory_option)
                else:
                    expected_imsi_prefixes[directory] = None
                
                if tcp_partial_validator_monitor_config.has_option('datetime_enrichment_options', output_directory_option):
                    datetime_enrichment_options[directory] = tcp_partial_validator_monitor_config.getboolean('datetime_enrichment_options', output_directory_option)
                else:
                    datetime_enrichment_options[directory] = False
                    
                if tcp_partial_validator_monitor_config.has_option('probe_numbers', output_directory_option):
                    probe_numbers[directory] = tcp_partial_validator_monitor_config.getint('probe_numbers', output_directory_option)
            
            self.__options['datetime_enrichment_options'] = datetime_enrichment_options
            self.__options['expected_imsi_prefixes']      = expected_imsi_prefixes                         
            self.__options['output_directories']          = output_directories
            self.__options['probe_numbers']               = probe_numbers
            
            datagen_logger.trace('%s options: %s', self.__class__.__name__, self.__options)
            
        else:
            datagen_logger.error('%s file does not exist in folder %s', configuration_filename, options['etc'])            
        
    def run(self):
        
        '''
         The nowait attribute is used for testing purpose only.
         It is not defined in the property file.
         If one would like to use this attribute, then it has to be manually added into the option dictionary object passed
         to the __init__ constructor
        '''
        nowait = bool(self.__options['nowait']) if self.__options.has_key('nowait') else False
        waittime = int(self.__options['wait_time']) if self.__options.has_key('wait_time') else 1
        
        try:       
                         
            while True:     
                if not nowait:
                    time.sleep(waittime*60)
                           
                self.__validate()
                
        except:
            datagen_logger.error("error during tcp partial file validation")
            sys.exit()
    
    def __validate(self):
        output_directories          = None
        input_directory_path        = None
        remove_after_compare        = None
        original_prefix             = None
        datetime_enrichment_options = None
        expected_imsi_prefixes      = None
        probe_numbers               = None
        number_of_probes            = None
        
        if self.__options.has_key('output_directories') :
            output_directories = self.__options['output_directories'] 
        else:
            datagen_logger.error('no output_directories found in the option')
            sys.exit()
        
        if self.__options.has_key('input_directory_path') :
            input_directory_path = self.__options['input_directory_path'] 
        else:
            datagen_logger.error('no input_directory_path found in the option')
            sys.exit()
        
        if self.__options.has_key('remove_after_compare') :
            remove_after_compare = self.__options['remove_after_compare'] 
        else:
            datagen_logger.error('no remove_after_compare found in the option')
            sys.exit()
        
        if self.__options.has_key('original_prefix') :
            original_prefix = self.__options['original_prefix'] 
        else:
            datagen_logger.error('no original_prefix found in the option')
            sys.exit()
        
        if self.__options.has_key('datetime_enrichment_options') :
            datetime_enrichment_options = self.__options['datetime_enrichment_options'] 
        else:
            datagen_logger.error('no datetime_enrichment_options found in the option')
            sys.exit()
                    
        if self.__options.has_key('expected_imsi_prefixes') :
            expected_imsi_prefixes = self.__options['expected_imsi_prefixes'] 
        else:
            datagen_logger.error('no expected_imsi_prefixes found in the option')
            sys.exit()
        
        if self.__options.has_key('probe_numbers'):
            probe_numbers = self.__options['probe_numbers']
        else:
            datagen_logger.error('no probe_numbers found in the option')
            sys.exit()  
        
        if self.__options.has_key('number_of_probes'):
            number_of_probes = self.__options['number_of_probes']
        else:
            datagen_logger.error('no number_of_probes found in the option')
            sys.exit()
            
        to_validate = self.__options['to_validate'] if self.__options.has_key('to_validate') else True
           
        output_directories.sort()    
                     
        for output_directory in output_directories:
            probe_number = probe_numbers[output_directory]

            enrich_datetime = datetime_enrichment_options[output_directory] if datetime_enrichment_options.has_key(output_directory) else None
            if enrich_datetime is None:
                datagen_logger.error('no value found in the datetime_enrichment_options for key %s in %s', output_directory, self.__class__.__name__)             
            expected_imsi_prefix = expected_imsi_prefixes[output_directory] if expected_imsi_prefixes.has_key(output_directory) else None
            if expected_imsi_prefix is None:
                datagen_logger.error('no value found in the expected_imsi_prefix for key %s in %s', output_directory, self.__class__.__name__) 
            
            if not output_directory.endswith(os.sep):
                output_directory = ''.join([output_directory, os.sep])
            
            if not os.path.exists(output_directory):
                datagen_logger.warning('output directory does not exist [%s]', output_directory)
                continue
            
            for generated_file in os.listdir(output_directory):
                
                validators = []
                
                original_file = find_staple_and_captool_file(generated_file, input_directory_path)
                
                if original_file == None:
                    datagen_logger.warning('no match file %s found in %s', generated_file, input_directory_path)
                    continue
                
                expected_datetime = None
                if enrich_datetime:
                    expected_datetime = get_expected_datetime(generated_file)
                else:
                    expected_datetime = get_expected_datetime(original_file)                
                datagen_logger.debug('expected datetime %s of Probe %d', expected_datetime, probe_number)
                
                validator_options = dict()
                
                validator_options['original_file_path']   = original_file
                validator_options['enriched_file_path']   = ''.join([output_directory,generated_file])
                validator_options['expected_datetime']    = expected_datetime
                validator_options['enriched_imsi_prefix'] = expected_imsi_prefix
                validator_options['original_imsi_prefix'] = original_prefix
                validator_options['remove_after_compare'] = remove_after_compare 
                validator_options['probe_number']         = probe_number
                validator_options['number_of_probes']     = number_of_probes
                
                validator = None
                if to_validate:
                    validator = TcpPartialValidator(validator_options)
                    validators.append(validator)
                
                if datagen_logger.isEnabledFor(logging.DEBUG):
                    datagen_logger.debug('-----------------------------------------------------------------')
                    if to_validate:
                        datagen_logger.debug('validator name %s', validator.name)
                    datagen_logger.debug('original file path %s', validator_options['original_file_path'])
                    datagen_logger.debug('enriched file path %s', validator_options['enriched_file_path'])
                    datagen_logger.debug('expected datetime %s', validator_options['expected_datetime'])
                    datagen_logger.debug('enriched imsi prefix %s', validator_options['enriched_imsi_prefix'])
                    datagen_logger.debug('original imsi prefix %s', validator_options['original_imsi_prefix'])
                    datagen_logger.debug('remove after compare %s', validator_options['remove_after_compare'])
                    datagen_logger.debug('number of probes %d', validator_options['number_of_probes'])
                    datagen_logger.debug('probe number %d', validator_options['probe_number'])
                    datagen_logger.debug('-----------------------------------------------------------------\n')
                
                if to_validate:    
                    for validator in validators:
                        validator.start()
                    
                    for validator in validators:
                        validator.join()
                
class ClassificationValidatorMointor(Process):
    
    def __init__(self, options):
        Process.__init__(self)
        configuration_filename = 'classification_validator.props'            
        if os.path.exists(options['etc']+os.sep+configuration_filename):
            classification_validator_monitor_config = ConfigParser()
            classification_validator_monitor_config.readfp(open(options['etc']+os.sep+configuration_filename))
            
            self.__options = dict()
            self.__options['input_directory_path'] = classification_validator_monitor_config.get('basic', 'input_directory_path')
            self.__options['remove_after_compare'] = classification_validator_monitor_config.getboolean('basic', 'remove_after_compare')
            self.__options['original_prefix']      = classification_validator_monitor_config.getint('basic', 'original_prefix')
            self.__options['wait_time']            = classification_validator_monitor_config.getint('basic', 'wait_time')
            self.__options['number_of_probes']     = classification_validator_monitor_config.getint('basic', 'number_of_probes')
            self.__options['nowait']               = options['nowait']
            
            output_directory_options = classification_validator_monitor_config.options('output_directories')
            output_directories = []
            expected_imsi_prefixes = {}
            datetime_enrichment_options = {}
            probe_numbers = {}
            for output_directory_option in output_directory_options:
                directory = classification_validator_monitor_config.get('output_directories', output_directory_option)
                if not directory.endswith(os.sep):
                    directory = ''.join([directory, os.sep])
                output_directories.append(directory)   
                if classification_validator_monitor_config.has_option('expected_imsi_prefixes', output_directory_option):
                    expected_imsi_prefixes[directory] = classification_validator_monitor_config.get('expected_imsi_prefixes', output_directory_option)
                else:
                    expected_imsi_prefixes[directory] = None
                
                if classification_validator_monitor_config.has_option('datetime_enrichment_options', output_directory_option):
                    datetime_enrichment_options[directory] = classification_validator_monitor_config.getboolean('datetime_enrichment_options', output_directory_option)
                else:
                    datetime_enrichment_options[directory] = False
                    
                if classification_validator_monitor_config.has_option('probe_numbers', output_directory_option):
                    probe_numbers[directory] = classification_validator_monitor_config.getint('probe_numbers', output_directory_option)
                
            self.__options['datetime_enrichment_options'] = datetime_enrichment_options
            self.__options['expected_imsi_prefixes']      = expected_imsi_prefixes         
            self.__options['output_directories']          = output_directories
            self.__options['probe_numbers']               = probe_numbers
            
            datagen_logger.trace('%s options: %s', self.__class__.__name__, self.__options)
        else:
            datagen_logger.error('%s file does not exist in folder %s', configuration_filename, options['etc'])
        
    def run(self):
        
        '''
         The nowait attribute is used for testing purpose only.
         It is not defined in the property file.
         If one would like to use this attribute, then it has to be manually added into the option dictionary object passed
         to the __init__ constructor
        '''
        nowait = bool(self.__options['nowait']) if self.__options.has_key('nowait') else False
        waittime = int(self.__options['wait_time']) if self.__options.has_key('wait_time') else 1
        
        try:       
            
            while True:     
                if not nowait:
                    time.sleep(waittime*60)
                           
                self.__validate()
                
        except :
            datagen_logger.error("error during classification file validation")
            sys.exit()
    
    def __validate(self):
        
        output_directories          = None
        input_directory_path        = None
        remove_after_compare        = None
        original_prefix             = None
        datetime_enrichment_options = None
        expected_imsi_prefixes      = None
        probe_numbers               = None
        number_of_probes            = None
        
        if self.__options.has_key('output_directories') :
            output_directories = self.__options['output_directories'] 
        else:
            datagen_logger.error('no output_directories found in the option')
            sys.exit()
        
        if self.__options.has_key('input_directory_path') :
            input_directory_path = self.__options['input_directory_path'] 
        else:
            datagen_logger.error('no input_directory_path found in the option')
            sys.exit()
        
        if self.__options.has_key('remove_after_compare') :
            remove_after_compare = self.__options['remove_after_compare'] 
        else:
            datagen_logger.error('no remove_after_compare found in the option')
            sys.exit()
        
        if self.__options.has_key('original_prefix') :
            original_prefix = self.__options['original_prefix'] 
        else:
            datagen_logger.error('no original_prefix found in the option')
            sys.exit()
        
        if self.__options.has_key('datetime_enrichment_options') :
            datetime_enrichment_options = self.__options['datetime_enrichment_options'] 
        else:
            datagen_logger.error('no datetime_enrichment_options found in the option')
            sys.exit()
            
        if self.__options.has_key('expected_imsi_prefixes') :
            expected_imsi_prefixes = self.__options['expected_imsi_prefixes'] 
        else:
            datagen_logger.error('no expected_imsi_prefixes found in the option')
            sys.exit()
        
        if self.__options.has_key('probe_numbers'):
            probe_numbers = self.__options['probe_numbers']
        else:
            datagen_logger.error('no probe_numbers found in the option')
            sys.exit()
                    
        if self.__options.has_key('number_of_probes'):
            number_of_probes = self.__options['number_of_probes']
        else:
            datagen_logger.error('no number_of_probes found in the option')
            sys.exit()
            
        to_validate = self.__options['to_validate'] if self.__options.has_key('to_validate') else True
         
        output_directories.sort()
              
        for output_directory in output_directories:
            probe_number = probe_numbers[output_directory]
            
            enrich_datetime = datetime_enrichment_options[output_directory] if datetime_enrichment_options.has_key(output_directory) else None
            if enrich_datetime is None:
                datagen_logger.error('no value found in the datetime_enrichment_options for key %s in %s', output_directory, self.__class__.__name__)             
            expected_imsi_prefix = expected_imsi_prefixes[output_directory] if expected_imsi_prefixes.has_key(output_directory) else None
            if expected_imsi_prefix is None:
                datagen_logger.error('no value found in the expected_imsi_prefix for key %s in %s', output_directory, self.__class__.__name__)
                 
            if not output_directory.endswith(os.sep):
                output_directory = ''.join([output_directory, os.sep])
                                    
            if not os.path.exists(output_directory):
                datagen_logger.warning('output directory does not exist [%s]', output_directory)
                continue

            for generated_file in os.listdir(output_directory):
                
                validators = []
                
                original_file = find_staple_and_captool_file(generated_file, input_directory_path)
                
                if original_file == None:
                    datagen_logger.warning('no match file %s found in %s', generated_file, input_directory_path)
                    continue
                
                expected_datetime = None
                if enrich_datetime:
                    expected_datetime = get_expected_datetime(generated_file)
                else:
                    expected_datetime = get_expected_datetime(original_file)                
                datagen_logger.debug('expected datetime %s of Probe %d', expected_datetime, probe_number)
                
                validator_options = dict()
                
                validator_options['original_file_path']   = original_file
                validator_options['enriched_file_path']   = ''.join([output_directory,generated_file])
                validator_options['expected_datetime']    = expected_datetime
                validator_options['enriched_imsi_prefix'] = expected_imsi_prefix
                validator_options['original_imsi_prefix'] = original_prefix
                validator_options['remove_after_compare'] = remove_after_compare 
                validator_options['probe_number']         = probe_number
                validator_options['number_of_probes']     = number_of_probes
                
                validator = None
                if to_validate:
                    validator = ClassificationlValidator(validator_options)
                    validators.append(validator)
                
                if datagen_logger.isEnabledFor(logging.DEBUG):
                    datagen_logger.debug('-----------------------------------------------------------------')
                    if to_validate:
                        datagen_logger.debug('validator name %s', validator.name)
                    datagen_logger.debug('original file path %s', validator_options['original_file_path'])
                    datagen_logger.debug('enriched file path %s', validator_options['enriched_file_path'])
                    datagen_logger.debug('expected datetime %s', validator_options['expected_datetime'])
                    datagen_logger.debug('enriched imsi prefix %s', validator_options['enriched_imsi_prefix'])
                    datagen_logger.debug('original imsi prefix %s', validator_options['original_imsi_prefix'])
                    datagen_logger.debug('remove after compare %s', validator_options['remove_after_compare'])
                    datagen_logger.debug('number of probes %d', validator_options['number_of_probes'])
                    datagen_logger.debug('probe number %d', validator_options['probe_number'])
                    datagen_logger.debug('-----------------------------------------------------------------\n')
            
                if to_validate:    
                    for validator in validators:
                        validator.start()
                    
                    for validator in validators:
                        validator.join()
