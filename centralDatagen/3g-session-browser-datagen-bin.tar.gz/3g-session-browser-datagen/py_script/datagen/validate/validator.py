'''
Created on Sep 20, 2012

@author: epstvxj
'''

import os
from datagen.validate.compare_sgeh import compare_sgeh_data
from multiprocessing.process import Process
from datagen.settings import datagen_logger
from datagen.validate.compare_gpeh import compare_gpeh_data
from datagen.validate.compare_tcp_partial import compare_tcp_partial_data
from datagen.validate.compare_classification import compare_classification_data

class SgehValidator(Process):
    
    def __init__(self, options):
        Process.__init__(self)
        
        self.__original_file_path   = options['original_file_path']
        self.__enriched_file_path   = options['enriched_file_path']
        self.__expected_datetime    = options['expected_datetime']
        self.__enriched_imsi_prefix = options['enriched_imsi_prefix']
        self.__original_imsi_prefix = options['original_imsi_prefix']
        self.__remove_after_compare = options['remove_after_compare']
            
    def run(self):                                           
        compare_sgeh_data(self.__original_file_path, self.__enriched_file_path, self.__expected_datetime, str(self.__enriched_imsi_prefix), str(self.__original_imsi_prefix))
        
        if self.__remove_after_compare and os.path.exists(self.__enriched_file_path):
            datagen_logger.debug('file %s removed', self.__enriched_file_path)
            os.remove(self.__enriched_file_path)
        
        datagen_logger.info('=======================================')
        datagen_logger.info('sgeh data validation process finished by %s', self._name)
        datagen_logger.info('original file: %s', self.__original_file_path)
        datagen_logger.info('enriched file: %s', self.__enriched_file_path)
        datagen_logger.info('=======================================\n')

class TcpPartialValidator(Process):
    
    def __init__(self, options):
        Process.__init__(self)
        
        self.__original_file_path   = options['original_file_path']
        self.__enriched_file_path   = options['enriched_file_path']
        self.__expected_datetime    = options['expected_datetime']
        self.__enriched_imsi_prefix = options['enriched_imsi_prefix']
        self.__original_imsi_prefix = options['original_imsi_prefix']
        self.__remove_after_compare = options['remove_after_compare']
        self.__number_of_probes     = options['number_of_probes']
        self.__probe_number         = options['probe_number']
    
    def run(self):                                           
        compare_tcp_partial_data(self.__original_file_path, self.__enriched_file_path, self.__expected_datetime, 
                                 str(self.__enriched_imsi_prefix), str(self.__original_imsi_prefix), 
                                 self.__number_of_probes, self.__probe_number)
        
        if self.__remove_after_compare and os.path.exists(self.__enriched_file_path):
            datagen_logger.debug('file %s removed', self.__enriched_file_path)
            os.remove(self.__enriched_file_path)
        
        datagen_logger.info('=======================================')
        datagen_logger.info('tcp partial data validation process finished by %s', self._name)
        datagen_logger.info('original file: %s', self.__original_file_path)
        datagen_logger.info('enriched file: %s', self.__enriched_file_path)
        datagen_logger.info('=======================================\n')
        
class ClassificationlValidator(Process):
    
    def __init__(self, options):
        Process.__init__(self)
        
        self.__original_file_path   = options['original_file_path']
        self.__enriched_file_path   = options['enriched_file_path']
        self.__expected_datetime    = options['expected_datetime']
        self.__enriched_imsi_prefix = options['enriched_imsi_prefix']
        self.__original_imsi_prefix = options['original_imsi_prefix']
        self.__remove_after_compare = options['remove_after_compare']
        self.__number_of_probes     = options['number_of_probes']
        self.__probe_number         = options['probe_number']
    
    def run(self):                                           
        compare_classification_data(self.__original_file_path, self.__enriched_file_path, self.__expected_datetime, 
                                    str(self.__enriched_imsi_prefix), str(self.__original_imsi_prefix),
                                    self.__number_of_probes, self.__probe_number)
        
        if self.__remove_after_compare and os.path.exists(self.__enriched_file_path):
            datagen_logger.debug('file %s removed', self.__enriched_file_path)
            os.remove(self.__enriched_file_path)
        
        datagen_logger.info('=======================================')
        datagen_logger.info('classification data validation process finished by %s', self._name)
        datagen_logger.info('original file: %s', self.__original_file_path)
        datagen_logger.info('enriched file: %s', self.__enriched_file_path)
        datagen_logger.info('=======================================\n')
          
class GpehValidator(Process):
    
    def __init__(self, options):
        Process.__init__(self)
        
        self.__original_files       = options['original_files']
        self.__enriched_files       = options['enriched_files']
        self.__expected_datetime    = options['expected_datetime']
        self.__enriched_imsi_prefix = options['enriched_imsi_prefix']
        self.__original_imsi_prefix = options['original_imsi_prefix']
        self.__remove_after_compare = options['remove_after_compare']
    
    def run(self):                                           
                
        compare_gpeh_data(self.__original_files, self.__enriched_files, self.__expected_datetime, str(self.__enriched_imsi_prefix), str(self.__original_imsi_prefix))
        
        if self.__remove_after_compare: 
            for enriched_file in self.__enriched_files:
                if os.path.exists(enriched_file):
                    datagen_logger.debug('file %s removed', enriched_file)
                    os.remove(enriched_file)
        
        datagen_logger.info('=======================================')
        datagen_logger.info('gpeh data validation process finished by %s', self._name)
        datagen_logger.info('original files: %s', self.__original_files)
        datagen_logger.info('enriched files: %s', self.__enriched_files)
        datagen_logger.info('=======================================\n')
        