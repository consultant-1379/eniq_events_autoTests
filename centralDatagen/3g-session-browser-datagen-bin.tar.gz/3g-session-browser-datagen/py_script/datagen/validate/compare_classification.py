'''
Created on Sep 3, 2012

@author: epstvxj
'''

from datetime import datetime
from datagen.settings import datagen_logger
import os


def compare_classification_data(original_file, enriched_file, expected_datetime, expected_imsi_prefix, 
                                original_imsi_prefix, number_of_probes, probe_number):
    
    if not os.path.exists(original_file):
        datagen_logger.error('original file %s does not exist', original_file)
        return
    if not os.path.exists(enriched_file):
        datagen_logger.error('enriched file %s does not exist', enriched_file)
        return
    
    f_original = open(original_file)
    f_enriched = open(enriched_file)
    
    try:
        line_count = 0
        record_number = 1
        for line_in_original_file in f_original:

            line_count += 1
            
            if (line_count % number_of_probes == probe_number) or (line_count % number_of_probes == 0 and probe_number == number_of_probes):
            
                line_in_enriched_file = f_enriched.readline()
            
                orignal_fields = line_in_original_file.strip().split('|')
                enriched_fields = line_in_enriched_file.strip().split('|')
                
                if len(enriched_fields) <= 3:
                    datagen_logger.error('record %d, enriched record length is %d [%s], original record length is %d [%s]', record_number, len(enriched_fields), enriched_file, len(orignal_fields), original_file)
                    continue
                record_number += 1
                
                original_imsi = orignal_fields[3]
                enriched_imsi = enriched_fields[3]
                
                if not enriched_imsi.startswith(expected_imsi_prefix):
                    datagen_logger.error('enriched imsi prefix [%s] does not match given expected imsi prefix [%s]', enriched_imsi, expected_imsi_prefix)
                
                original_imsi_suffix = original_imsi[len(original_imsi_prefix)+1:] 
                enriched_imsi_suffix = enriched_imsi[len(expected_imsi_prefix)+1:]
                
                if original_imsi_suffix != enriched_imsi_suffix:
                    datagen_logger.error('original imsi suffix [%s] does not match enriched imsi suffix [%s]', original_imsi_suffix, enriched_imsi_suffix)
               
                enriched_start_timestamp = float(enriched_fields[1])
                enriched_start_datetime = datetime.utcfromtimestamp(enriched_start_timestamp) 
                
                enriched_end_timestamp = float(enriched_fields[2])
                enriched_end_datetime = datetime.utcfromtimestamp(enriched_end_timestamp) 
    
                if enriched_start_datetime.year != expected_datetime.year:
                    datagen_logger.error('year of enriched start datetime does not match %d != %d', enriched_start_datetime.year, expected_datetime.year)
                if enriched_start_datetime.month != expected_datetime.month:
                    datagen_logger.error('month of enriched start datetime does not match %d != %d', enriched_start_datetime.month, expected_datetime.month)
                if enriched_start_datetime.day != expected_datetime.day:
                    datagen_logger.error('day of enriched start datetime does not match %d != %d', enriched_start_datetime.day, expected_datetime.day)                
                if enriched_end_datetime.year != expected_datetime.year:
                    datagen_logger.error('year of enriched end datetime does not match %d != %d', enriched_end_datetime.year, expected_datetime.year)
                if enriched_end_datetime.month != expected_datetime.month:
                    datagen_logger.error('month of enriched end datetime does not match %d != %d', enriched_end_datetime.month, expected_datetime.month)
                if enriched_end_datetime.day != expected_datetime.day:
                    datagen_logger.error('day of enriched end datetime does not match %d != %d', enriched_end_datetime.day, expected_datetime.day)                  

    finally:
        f_original.close()
        f_enriched.close()  
    