'''
Created on Sep 24, 2012

@author: epstvxj
'''
from datagen.settings import datagen_logger
from datagen.shared.constants import GPEH_FOOTER_RECORD, GPEH_HEADER_RECORD, \
    GPEH_RECORDING_RECORD, GPEH_PROTOCOL_RECORD, GPEH_BODY_RECORD, GPEH_LINK_RECORD, \
    GPEH_ERROR_RECORD
from datagen.shared.data_utility import get_value, \
    get_integer_value_from_byte_list
from datagen.validate.events import gpeh_events_mapping
from glob import glob
from struct import unpack
import binascii
import gzip
import os
import re

original_all_events_count_map = {}
enriched_all_events_count_map = {}

def compare_gpeh_data(original_files, enriched_files, expected_datetime, enriched_imsi_prefix, original_imsi_prefix):
    
    for original_file in original_files:
        if not os.path.exists(original_file):
            datagen_logger.error('original file %s does not exist', original_file)
            return
    
    for enriched_file in enriched_files:
        if not os.path.exists(original_file):
            datagen_logger.error('enriched file %s does not exist', enriched_file)
            return
    
    original_filemap = {}
    enriched_filemap = {}
    
    pattern = re.compile('(Mp\d*.bin.gz)')      
    for original_file in original_files:      
        key = pattern.search(original_file).group(1)
        print(key)
        original_filemap[key] = original_file
    for enriched_file in enriched_files:          
        key = pattern.search(enriched_file).group(1)
        enriched_filemap[key] = enriched_file 
    
    original_mp0 = original_filemap.pop('Mp0.bin.gz') 
    enriched_mp0 = enriched_filemap.pop('Mp0.bin.gz')        
            
    number_of_link_records = compare_mp0_file(original_mp0, enriched_mp0, expected_datetime)
    
    assert(number_of_link_records == len(original_filemap))
    assert(number_of_link_records == len(enriched_filemap))
    
    for item in original_filemap.items() :
        datagen_logger.debug(item)
        original_file = original_filemap[item[0]]
        enriched_file = enriched_filemap[item[0]]
        
        compare_mpN_file(original_file, enriched_file)
        
    for item in original_all_events_count_map.items():
        original_event_name = gpeh_events_mapping[item[0]]
        original_event_count = item[1]        
        enriched_event_count = enriched_all_events_count_map[item[0]]
        if original_event_count != enriched_event_count:
            datagen_logger.error('total number of %s event(s) [%d != %d] does not match', original_event_name,
                          original_event_count, enriched_event_count)

def compare_mpN_file(original_file, enriched_file):
    f_original = None
    f_enriched = None
    
    if original_file.endswith('bin.gz'):
        f_original = gzip.open(original_file, 'rb')
    else:
        f_original = open(original_file, 'rb')
    
    if enriched_file.endswith('bin.gz'):
        f_enriched = gzip.open(enriched_file, 'rb')
    else:
        f_enriched = open(enriched_file, 'rb')
        
    original_record_type = 0 
    enriched_record_type = 0
    
    original_event_count_map = {}
    enriched_event_count_map = {}
    while True:
        try:
            original_record_length, enriched_record_length = process_record_length(f_original, f_enriched)
            assert(original_record_length==enriched_record_length)
            
            original_bytes = f_original.read(original_record_length-2)
            enriched_bytes = f_enriched.read(enriched_record_length-2)
        
            original_record_type, enriched_record_type = process_next_record_type(original_bytes, enriched_bytes)
            assert(original_record_type==enriched_record_type)
            
            original_byte_list = unpack(''.join(['>',str(original_record_length-2),'B']), original_bytes)
            enriched_byte_list = unpack(''.join(['>',str(enriched_record_length-2),'B']), enriched_bytes)
            
            # bit offset of event id
            offset = 61            
            if (original_record_length-2)*8 < 61+10:
                print(original_record_length,enriched_record_length)
                continue
            
            original_unpacked_byte_list = get_value(10, (8-offset%8), offset, original_byte_list)[2]
            
            original_event_id = get_integer_value_from_byte_list(original_unpacked_byte_list, 10)
            
            if original_event_id not in original_event_count_map:
                original_event_count_map[original_event_id] = 0
            original_event_count_map[original_event_id] += 1
            
            if original_event_id not in original_all_events_count_map:
                original_all_events_count_map[original_event_id] = 0
            original_all_events_count_map[original_event_id] += 1
            
            # bit offset of event id
            offset = 61            
            if (enriched_record_length-2)*8 < 61+10:
                print(enriched_record_length)
                continue
            
            enriched_unpacked_byte_list = get_value(10, (8-offset%8), offset, enriched_byte_list)[2]
            
            enriched_event_id = get_integer_value_from_byte_list(enriched_unpacked_byte_list, 10)
            
            if enriched_event_id not in enriched_event_count_map:
                enriched_event_count_map[enriched_event_id] = 0
            enriched_event_count_map[enriched_event_id] += 1
            
            if enriched_event_id not in enriched_all_events_count_map:
                enriched_all_events_count_map[enriched_event_id] = 0
            enriched_all_events_count_map[enriched_event_id] += 1
            
            
        except ValueError:            
            if f_original.tell()!=f_enriched.tell():
                datagen_logger.error('%s and %s does not match',original_file, enriched_file)            
            break
    
    for item in original_event_count_map.items():
        original_event_name = gpeh_events_mapping[item[0]]
        original_event_count = item[1]        
        enriched_event_count = enriched_event_count_map[item[0]]
        if original_event_count != enriched_event_count:
            datagen_logger.error('number of %s event(s) [%d != %d] does not match between rop file %s, %s', original_event_name,
                          original_event_count, enriched_event_count, original_file, enriched_file)

def compare_mp0_file(original_mp0, enriched_mp0, expected_datetime):
    
    f_original = None
    f_enriched = None
    
    if original_mp0.endswith('bin.gz'):
        f_original = gzip.open(original_mp0, 'rb')
    else:
        f_original = open(original_mp0, 'rb')
    
    if enriched_mp0.endswith('bin.gz'):
        f_enriched = gzip.open(enriched_mp0, 'rb')
    else:
        f_enriched = open(enriched_mp0, 'rb')
    
    number_of_link_records = 0
    
    try:
        original_record_type = -1 
        enriched_record_type = -1
        
        while original_record_type != GPEH_FOOTER_RECORD:
            original_record_length, enriched_record_length = process_record_length(f_original, f_enriched)
            
            original_bytes = f_original.read(original_record_length-2)
            enriched_bytes = f_enriched.read(enriched_record_length-2)
            
            original_record_type, enriched_record_type = process_next_record_type(original_bytes, enriched_bytes)
            assert(original_record_type==enriched_record_type)
            
            if original_record_type == GPEH_HEADER_RECORD:
                process_header_record(original_bytes, enriched_bytes, expected_datetime)
            
            elif original_record_type == GPEH_RECORDING_RECORD:
                process_recording_record(original_bytes, enriched_bytes)                
            
            elif original_record_type == GPEH_PROTOCOL_RECORD:
                process_protocol_record(original_bytes, enriched_bytes)       
                         
            elif original_record_type == GPEH_BODY_RECORD:
                datagen_logger.debug('body record')
                process_body_record(original_bytes, enriched_bytes)
                
            elif original_record_type == GPEH_FOOTER_RECORD:               
                process_footer_record(original_bytes, enriched_bytes, expected_datetime)
                break
            
            elif original_record_type == GPEH_LINK_RECORD:
                process_link_record(original_bytes, enriched_bytes)
                number_of_link_records += 1
            
            elif original_record_type == GPEH_ERROR_RECORD:
                process_error_record(original_bytes, enriched_bytes)
        
        datagen_logger.info('number of files, including mp0, in the rop is %d', number_of_link_records+1)
        
    finally:
        f_original.close()
        f_enriched.close()
    
    return number_of_link_records
                
def process_body_record(original_bytes, enriched_bytes):
    pass        
        
def process_link_record(original_bytes, enriched_bytes):    
    offset = 1
    byte_length = len(original_bytes)
    while offset != byte_length:
        if original_bytes[offset] != enriched_bytes[offset]:
            datagen_logger.error('byte at offset position %d does not match between link records', offset)
        offset += 1
    
    original_external_link = ''.join(unpack(''.join([str(byte_length-1),'c']), original_bytes[1:]))    
    enriched_external_link = ''.join(unpack(''.join([str(byte_length-1),'c']), enriched_bytes[1:]))
    
    if original_external_link != enriched_external_link:
        datagen_logger.error('external link does not match between %s != %s', original_external_link, enriched_external_link)       
    
def process_footer_record(original_bytes, enriched_bytes, expected_datetime):
    offset = 1
        
    original_year = int(binascii.hexlify(original_bytes[offset:offset+2]),base=16) 
    enriched_year = int(binascii.hexlify(enriched_bytes[offset:offset+2]),base=16) 
    if original_year != enriched_year:
        datagen_logger.error('expected year %d does not match enriched year %d in the footer record', original_year, enriched_year)
    offset += 2
    
    enriched_month = int(binascii.hexlify(enriched_bytes[offset:offset+1]),base=16)    
    if expected_datetime.month != enriched_month:
        datagen_logger.error('expected month %d does not match enriched month %d in the footer record', expected_datetime.month, enriched_month)    
    offset += 1     
    
    enriched_day = int(binascii.hexlify(enriched_bytes[offset:offset+1]),base=16)
    if expected_datetime.day != enriched_day:
        datagen_logger.error('expected day %d does not match enriched day %d in the footer record', expected_datetime.day, enriched_day)
    offset += 1
        
    byte_length = len(original_bytes)
    while offset != byte_length:
        if original_bytes[offset] != enriched_bytes[offset]:
            datagen_logger.error('byte at offset position %d does not match between footer records', offset)
        offset += 1
    
def process_error_record(original_bytes, enriched_bytes):
    offset = 1
    byte_length = len(original_bytes)
    while offset != byte_length:
        if original_bytes[offset] != enriched_bytes[offset]:
            datagen_logger.error('byte at offset position %d does not match between error records', offset)
        offset += 1

def process_protocol_record(original_bytes, enriched_bytes):
    offset = 1
    byte_length = len(original_bytes)
    while offset != byte_length:
        if original_bytes[offset] != enriched_bytes[offset]:
            datagen_logger.error('byte at offset position %d does not match between protocol records', offset)
        offset += 1

def process_recording_record(original_bytes, enriched_bytes):
    index = 0
    for original_byte in original_bytes:
        if original_byte != enriched_bytes[index]:
            datagen_logger.error('byte at offset position %d does not match between recording records', index)
        index += 1
    
def process_record_length(f_original, f_enriched):
    original_bytes = f_original.read(2)
    enriched_bytes = f_enriched.read(2)
    
    original_record_length = int(binascii.hexlify(original_bytes),base=16)
    enriched_record_length = int(binascii.hexlify(enriched_bytes),base=16)
    
    if original_record_length != enriched_record_length:
        datagen_logger.error('record length does not match %d != %d', original_record_length, enriched_record_length)
        
    return original_record_length, enriched_record_length
        
def process_next_record_type(original_bytes, enriched_bytes):
    
    original_record_type = int(binascii.hexlify(original_bytes[0:1]),base=16)
    enriched_record_type = int(binascii.hexlify(enriched_bytes[0:1]),base=16)
    
    if original_record_type != enriched_record_type:
        datagen_logger.error('record type does not match %d != %d', original_record_type, enriched_record_type)
    
    return original_record_type, enriched_record_type

def process_header_record(original_bytes, enriched_bytes, expected_datetime):
    
    original_ffv = ''.join(unpack(''.join(['5c']), original_bytes[1:6]))
    enriched_ffv = ''.join(unpack(''.join(['5c']), enriched_bytes[1:6]))
    
    if original_ffv != enriched_ffv:
        datagen_logger.error('file format version does not match, expected: %s, actual: %s', original_ffv, enriched_ffv)
        
    offset = 6
        
    original_year = int(binascii.hexlify(original_bytes[offset:offset+2]),base=16) 
    enriched_year = int(binascii.hexlify(enriched_bytes[offset:offset+2]),base=16) 
    
    offset += 2    
    if original_year != enriched_year:
        datagen_logger.error('expected year %d does not match enriched year %d in the header record', original_year, enriched_year)
        
    enriched_month = int(binascii.hexlify(enriched_bytes[offset:offset+1]),base=16)
    
    if expected_datetime.month != enriched_month:
        datagen_logger.error('expected month %d does not match enriched month %d in the header record', expected_datetime.month, enriched_month)
    
    offset += 1     
    enriched_day = int(binascii.hexlify(enriched_bytes[offset:offset+1]),base=16)
    offset += 1
    
    if expected_datetime.day != enriched_day:
        datagen_logger.error('expected day %d does not match enriched day %d in the header record', expected_datetime.day, enriched_day)
    
    original_fiv = ''.join(unpack(''.join(['5c']), original_bytes[-5:])) 
    enriched_fiv = ''.join(unpack(''.join(['5c']), enriched_bytes[-5:]))
    
    if original_fiv != enriched_fiv:
        datagen_logger.error('file information on version does not match, expected: %s, actual: %s', original_fiv, enriched_fiv)
    
    original_ne_user_label = ''.join(unpack(''.join(['200c']), original_bytes[213:413]))
    enriched_ne_user_label = ''.join(unpack(''.join(['200c']), enriched_bytes[213:413]))
    
    if original_ne_user_label != enriched_ne_user_label:
        datagen_logger.error('ne user labels are different, original %s, enriched %s', original_ne_user_label, enriched_ne_user_label)
    
    original_ne_logical_name = ''.join(unpack(''.join(['200c']), original_bytes[13:213]))
    enriched_ne_logical_name = ''.join(unpack(''.join(['200c']), enriched_bytes[13:213]))
    
    if original_ne_logical_name == enriched_ne_logical_name:
        datagen_logger.error('ne logical name are same, both equal to %s', enriched_ne_logical_name)
        
def find_mp0_files(path):
    
    if not path.endswith(os.sep):
        path = ''.join([path,os.sep]) 
    
    mp0s = glob(''.join([path, '*_rnc_gpehfile_Mp0.bin*']))
    
    return mp0s
    
def get_number_of_rop_files(mp0):
    
    if 'Mp0' not in mp0:
        datagen_logger.error('not a mp0 file %s', mp0)
        return -1
    
    f = None
    
    if mp0.endswith('bin.gz'):
        f = gzip.open(mp0, 'rb')
    else:
        f = open(mp0, 'rb')
        
    number_of_sub_files = 0
    
    record_type = -1
    while record_type != GPEH_FOOTER_RECORD:
        
        data_bytes = f.read(2)
        record_length = int(binascii.hexlify(data_bytes),base=16)
        
        data_bytes = f.read(1)
        record_type = int(binascii.hexlify(data_bytes),base=16)
        
        data_bytes = f.read(record_length-3)
        
        if record_type == GPEH_LINK_RECORD:
            number_of_sub_files += 1    
        
    return number_of_sub_files+1 # count mp0

def get_prefix(mp0):
    
    prefix_start_index = mp0.rfind(''.join([os.sep,'A']))
    prefix_end_index = mp0.rfind('Mp0.bin')
    
    return mp0[prefix_start_index+1:prefix_end_index]

def get_match_files(pattern, path):
    if not path.endswith(os.sep):
        path = ''.join([path,os.sep])
    
    pattern = ''.join([path,pattern,'*'])
    print(pattern)
    return glob(pattern)

def get_prefix_with_no_date_and_rnc_info(mp0):
    prefix_start_index = mp0.rfind(''.join([os.sep,'A']))
    prefix_end_index = mp0.rfind('Mp0.bin')
    
    prefix = mp0[prefix_start_index+1:prefix_end_index]
    
    prefix_start_index = 0
    prefix_end_index = prefix.find('.')
    
    prefix = ''.join([prefix[prefix_start_index:1], '*', prefix[prefix_end_index:]])
    
    sub_network_index = prefix.find('SubNetwork=')
    me_context_index = prefix.find(',MeContext=')
    prefix = ''.join([prefix[0:sub_network_index+len('SubNetwork=')], 'RNC*', prefix[me_context_index:]])
    
    rnc_grepfile_index = prefix.find('_rnc_gpehfile')
    prefix = ''.join([prefix[0:sub_network_index+len(',MeContext=')], 'RNC*', prefix[rnc_grepfile_index:]])
        
    return prefix
