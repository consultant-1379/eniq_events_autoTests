#!/usr/bin/bash
OUTPUT_LOG="/var/log/3g-session-browser-datagen/datagen-output.log"
exec python -m datagen.__main__ --etc=/opt/ericsson/3g-session-browser-datagen/etc > ${OUTPUT_LOG} 2>&1 &