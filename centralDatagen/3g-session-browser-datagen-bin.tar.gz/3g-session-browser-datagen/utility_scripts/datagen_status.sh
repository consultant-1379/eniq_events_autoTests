#!/usr/bin/bash
STARTSTOP_LOG="/var/log/3g-session-browser-datagen/datagen-startstop.log"
python -m datagen.__main__ status >> ${STARTSTOP_LOG} 2>&1 