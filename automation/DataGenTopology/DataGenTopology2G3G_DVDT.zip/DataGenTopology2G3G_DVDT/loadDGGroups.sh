/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopology2G3G_DVDT/CreateAPN_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopology2G3G_DVDT/CreateIMSI_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopology2G3G_DVDT/CreateMCC_MNC_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopology2G3G_DVDT/CreateTAC_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopology2G3G_DVDT/CreateRATVENDHIER321_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopology2G3G_DVDT/CreateRATVENDHIER3_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopology2G3G_DVDT/CreateEVENTSRC_Group.xml
