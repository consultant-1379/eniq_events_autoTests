 /eniq/sybase_iq/IQ-15_2/bin64/iqisql -Udc -Pdc -Sdwhdb -createDG.sql -ocreateDG3.out
