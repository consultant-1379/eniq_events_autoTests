update dc.DIM_E_SGEH_APN 
set APN = REPLACE(APN, 0x0a, ''), 
    LAST_SEEN = convert(datetime,getdate()),
    STATUS = 'ACTIVE',
    VENDOR = 'ERICSSON',
    CREATED = convert(datetime,getdate()),
    MODIFIED = convert(datetime,getdate()),
    MODIFIER = 'ENIQ_EVENTS';
GO 
update dc.DIM_E_SGEH_HIER321 set status ='ACTIVE';
update dc.dim_e_sgeh_ggsn set status = 'ACTIVE';
update dc.dim_e_sgeh_sgsn set status = 'ACTIVE';
GO
