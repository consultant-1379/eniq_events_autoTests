/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopology4G/CreateAPN_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopology4G/CreateIMSI_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopology4G/CreateMCC_MNC_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopology4G/CreateTAC_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopology4G/CreateRATVENDHIER321_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopology4G/CreateRATVENDHIER3_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopology4G/CreateEVENTSRC_Group.xml
