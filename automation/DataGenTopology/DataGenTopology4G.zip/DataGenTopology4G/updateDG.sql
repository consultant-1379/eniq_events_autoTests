update dc.DIM_E_SGEH_APN 
set APN = REPLACE(APN, 0x0a, ''), 
    LAST_SEEN = convert(datetime,getdate()),
    VENDOR = 'ERICSSON',
    STATUS = 'ACTIVE',
    CREATED = convert(datetime,getdate()),
    MODIFIED = convert(datetime,getdate()),
    MODIFIER = 'ENIQ_EVENTS';
GO 
update dc.DIM_E_SGEH_HIER321 set status='ACTIVE';
GO
