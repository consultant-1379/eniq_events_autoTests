/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopologyMSS/CreateAPN_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopologyMSS/CreateIMSI_MSS_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopologyMSS/CreateMCC_MNC_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopologyMSS/CreateTAC_MSS_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopologyMSS/CreateRATVENDHIER321_MSS_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopologyMSS/CreateRATVENDHIER3_MSS_Group.xml
/eniq/sw/bin/gpmgt -i -add -f  /eniq/home/dcuser/automation/DataGenTopology/DataGenTopologyMSS/CreateEVENTSRC_MSS_Group.xml
